import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import compression from 'compression';
import path from 'path';
import { config } from './config/index.js';
import api from './routes/index.js';
import { globalLimiter } from './middleware/rateLimiter.js';
import { notFound, errorHandler } from './middleware/errorHandler.js';

export function createApp() {
  const app = express();
  app.set('trust proxy', 1);
  app.use(helmet());
  app.use(cors({ origin: config.clientUrl, credentials: true }));
  app.use(compression());
  app.use(express.json({ limit: '2mb' }));
  app.use(express.urlencoded({ extended: true }));
  app.use(morgan(config.env === 'development' ? 'dev' : 'combined'));
  app.use(globalLimiter);

  // static uploads (logos, signatures, report-card PDFs)
  app.use('/uploads', express.static(path.resolve(config.uploadDir)));

  app.get('/health', (req, res) => res.json({ status: 'ok', ts: new Date().toISOString() }));
  app.use('/api', api);

  app.use(notFound);
  app.use(errorHandler);
  return app;
}
