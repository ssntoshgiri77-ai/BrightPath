import { createApp } from './app.js';
import { config } from './config/index.js';
import { pool } from './config/db.js';

const app = createApp();
const server = app.listen(config.port, () => {
  console.log(`\n🎓 School ERP API running on http://localhost:${config.port}`);
  console.log(`   Env: ${config.env}  |  Client: ${config.clientUrl}\n`);
});

async function shutdown(sig) {
  console.log(`\n${sig} received, shutting down...`);
  server.close(async () => { await pool.end(); process.exit(0); });
}
['SIGINT','SIGTERM'].forEach(s => process.on(s, () => shutdown(s)));
