import rateLimit from 'express-rate-limit';

// Strict limiter for the public result portal (anti brute-force on DOB/last name)
export const publicResultLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts. Please try again later.' },
});

export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  message: { error: 'Too many login attempts. Please try again later.' },
});

export const globalLimiter = rateLimit({ windowMs: 60 * 1000, max: 300 });
