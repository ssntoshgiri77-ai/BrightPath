export function notFound(req, res) {
  res.status(404).json({ error: 'Route not found' });
}

export function errorHandler(err, req, res, next) { // eslint-disable-line
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({
    error: err.publicMessage || err.message || 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && status >= 500 ? { stack: err.stack } : {}),
  });
}
