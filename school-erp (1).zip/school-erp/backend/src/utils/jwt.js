import jwt from 'jsonwebtoken';
import { config } from '../config/index.js';

export const signAccessToken = (payload) =>
  jwt.sign(payload, config.jwt.secret, { expiresIn: config.jwt.expires });

export const signRefreshToken = (payload) =>
  jwt.sign(payload, config.jwt.secret, { expiresIn: config.jwt.refreshExpires });

export const verifyToken = (token) => jwt.verify(token, config.jwt.secret);
