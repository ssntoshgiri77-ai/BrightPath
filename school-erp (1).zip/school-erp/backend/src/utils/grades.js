// Grade band configuration (percentage -> grade)
const BANDS = [
  { min: 90, grade: 'A+' },
  { min: 80, grade: 'A'  },
  { min: 70, grade: 'B'  },
  { min: 60, grade: 'C'  },
  { min: 50, grade: 'D'  },
  { min: 35, grade: 'E'  },
  { min: 0,  grade: 'F'  },
];

export function gradeFor(percentage) {
  const p = Number(percentage) || 0;
  return (BANDS.find(b => p >= b.min) || { grade: 'F' }).grade;
}

export function remarkFor(percentage) {
  const p = Number(percentage) || 0;
  if (p >= 90) return 'Outstanding performance. Keep it up!';
  if (p >= 75) return 'Very good. Consistent effort shown.';
  if (p >= 60) return 'Good, but there is room for improvement.';
  if (p >= 35) return 'Needs to work harder next term.';
  return 'Requires immediate academic support.';
}
