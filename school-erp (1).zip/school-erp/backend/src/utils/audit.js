import { query } from '../config/db.js';

export async function audit({ schoolId, actorId, action, entity, entityId, metadata, ip }) {
  try {
    await query(
      `INSERT INTO audit_logs (school_id, actor_id, action, entity, entity_id, metadata, ip_address)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [schoolId || null, actorId || null, action, entity || null, entityId || null,
       metadata ? JSON.stringify(metadata) : null, ip || null]
    );
  } catch (e) {
    console.error('audit failed', e.message);
  }
}
