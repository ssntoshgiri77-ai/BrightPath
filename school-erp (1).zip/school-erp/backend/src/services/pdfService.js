import PDFDocument from 'pdfkit';
import fs from 'fs';
import path from 'path';
import { config } from '../config/index.js';

// Generate a branded report-card PDF and write it to disk. Returns the file path + public URL.
// data = {
//   school: { name, address, logoPath, principalSignaturePath },
//   classTeacherSignaturePath,
//   student: { fullName, admissionNo, className, sectionName, dob },
//   exam: { name },
//   subjects: [{ name, maxMarks, marksObtained, grade }],
//   totals: { total, maxTotal, percentage, grade, rank },
//   remarks
// }
export async function generateReportCard(data) {
  const dir = path.resolve(config.uploadDir, 'report-cards');
  fs.mkdirSync(dir, { recursive: true });
  const fileName = `report_${data.exam.id}_${data.student.id}.pdf`;
  const filePath = path.join(dir, fileName);

  await new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 40 });
    const stream = fs.createWriteStream(filePath);
    doc.pipe(stream);

    const brand = '#1e3a8a';

    // ---- Header with logo ----
    if (data.school.logoPath && fs.existsSync(data.school.logoPath)) {
      try { doc.image(data.school.logoPath, 40, 35, { width: 60 }); } catch {}
    }
    doc.fillColor(brand).fontSize(20).font('Helvetica-Bold')
       .text(data.school.name, 110, 40);
    doc.fillColor('#444').fontSize(9).font('Helvetica')
       .text(data.school.address || '', 110, 65);
    doc.moveTo(40, 95).lineTo(555, 95).strokeColor(brand).lineWidth(2).stroke();
    doc.fillColor(brand).fontSize(14).font('Helvetica-Bold')
       .text(`REPORT CARD — ${data.exam.name}`, 40, 105, { align: 'center', width: 515 });

    // ---- Student details ----
    let y = 140;
    doc.fillColor('#111').fontSize(10).font('Helvetica');
    const rows = [
      ['Student Name', data.student.fullName, 'Admission No', data.student.admissionNo],
      ['Class', `${data.student.className} - ${data.student.sectionName}`, 'Date of Birth', data.student.dob],
    ];
    rows.forEach((r) => {
      doc.font('Helvetica-Bold').text(r[0] + ':', 40, y);
      doc.font('Helvetica').text(r[1] || '-', 140, y);
      doc.font('Helvetica-Bold').text(r[2] + ':', 320, y);
      doc.font('Helvetica').text(r[3] || '-', 430, y);
      y += 20;
    });

    // ---- Marks table ----
    y += 15;
    const cols = [
      { label: 'Subject',    x: 40,  w: 220 },
      { label: 'Max Marks',  x: 260, w: 90  },
      { label: 'Obtained',   x: 350, w: 90  },
      { label: 'Grade',      x: 440, w: 115 },
    ];
    doc.rect(40, y, 515, 22).fill(brand);
    doc.fillColor('#fff').fontSize(10).font('Helvetica-Bold');
    cols.forEach(c => doc.text(c.label, c.x + 6, y + 6, { width: c.w - 8 }));
    y += 22;

    doc.font('Helvetica').fontSize(10);
    data.subjects.forEach((s, i) => {
      if (i % 2 === 0) doc.rect(40, y, 515, 20).fill('#f1f5f9');
      doc.fillColor('#111');
      doc.text(s.name, cols[0].x + 6, y + 5, { width: cols[0].w - 8 });
      doc.text(String(s.maxMarks), cols[1].x + 6, y + 5, { width: cols[1].w - 8 });
      doc.text(String(s.marksObtained), cols[2].x + 6, y + 5, { width: cols[2].w - 8 });
      doc.text(s.grade || '-', cols[3].x + 6, y + 5, { width: cols[3].w - 8 });
      y += 20;
    });

    // ---- Totals ----
    y += 10;
    doc.rect(40, y, 515, 24).fill('#e2e8f0');
    doc.fillColor('#111').font('Helvetica-Bold').fontSize(11);
    doc.text(`Total: ${data.totals.total} / ${data.totals.maxTotal}`, 46, y + 6);
    doc.text(`Percentage: ${data.totals.percentage}%`, 240, y + 6);
    doc.text(`Grade: ${data.totals.grade}`, 430, y + 6);
    y += 34;
    if (data.totals.rank) {
      doc.font('Helvetica').fontSize(10).text(`Rank in section: ${data.totals.rank}`, 46, y);
      y += 20;
    }

    // ---- Remarks ----
    doc.font('Helvetica-Bold').fontSize(10).text('Remarks:', 40, y);
    doc.font('Helvetica').text(data.remarks || '', 100, y, { width: 455 });
    y += 60;

    // ---- Signatures ----
    const sigY = Math.max(y, 680);
    if (data.classTeacherSignaturePath && fs.existsSync(data.classTeacherSignaturePath)) {
      try { doc.image(data.classTeacherSignaturePath, 60, sigY - 30, { width: 90 }); } catch {}
    }
    if (data.school.principalSignaturePath && fs.existsSync(data.school.principalSignaturePath)) {
      try { doc.image(data.school.principalSignaturePath, 400, sigY - 30, { width: 90 }); } catch {}
    }
    doc.moveTo(60, sigY).lineTo(200, sigY).strokeColor('#333').lineWidth(1).stroke();
    doc.moveTo(360, sigY).lineTo(520, sigY).stroke();
    doc.fillColor('#111').fontSize(9).font('Helvetica')
       .text('Class Teacher', 60, sigY + 4)
       .text('Principal', 360, sigY + 4);

    doc.fillColor('#94a3b8').fontSize(7)
       .text(`Generated on ${new Date().toLocaleString()}`, 40, 800, { align: 'center', width: 515 });

    doc.end();
    stream.on('finish', resolve);
    stream.on('error', reject);
  });

  const publicUrl = `${config.publicBaseUrl}/uploads/report-cards/${fileName}`;
  return { filePath, publicUrl, fileName };
}
