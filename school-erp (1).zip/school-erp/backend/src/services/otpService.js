import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { query } from '../config/db.js';
import { sendEmail } from './emailService.js';

export async function generateOtp(schoolId, identifier) {
  const code = ('' + Math.floor(100000 + Math.random() * 900000));
  const codeHash = await bcrypt.hash(code, 8);
  const expires = new Date(Date.now() + 10 * 60 * 1000); // 10 min
  await query(
    `INSERT INTO otp_codes (school_id, identifier, code_hash, purpose, expires_at)
     VALUES ($1,$2,$3,'public_result',$4)`,
    [schoolId, identifier, codeHash, expires]
  );
  // Deliver (best-effort) — swallow errors so the flow still works in dev
  try {
    if (identifier.includes('@')) {
      await sendEmail({ to: identifier, subject: 'Your result access code',
        html: `<p>Your OTP is <b>${code}</b>. It expires in 10 minutes.</p>` });
    }
  } catch (e) { console.warn('OTP delivery failed:', e.message); }
  return { sent: true, devCode: process.env.NODE_ENV === 'development' ? code : undefined };
}

export async function verifyOtp(schoolId, identifier, code) {
  const { rows } = await query(
    `SELECT * FROM otp_codes WHERE school_id=$1 AND identifier=$2 AND purpose='public_result'
       AND consumed_at IS NULL AND expires_at > now() ORDER BY id DESC LIMIT 1`,
    [schoolId, identifier]
  );
  if (!rows.length) return false;
  const ok = await bcrypt.compare(code, rows[0].code_hash);
  if (ok) await query(`UPDATE otp_codes SET consumed_at=now() WHERE id=$1`, [rows[0].id]);
  return ok;
}
