import twilio from 'twilio';
import { config } from '../config/index.js';

let client = null;
function getClient() {
  if (client) return client;
  if (!config.twilio.sid || !config.twilio.token) return null;
  client = twilio(config.twilio.sid, config.twilio.token);
  return client;
}

// Template-based WhatsApp message via Twilio
export async function sendWhatsApp({ to, body }) {
  const c = getClient();
  if (!c) throw new Error('Twilio not configured');
  const msg = await c.messages.create({
    from: config.twilio.whatsappFrom,
    to: to.startsWith('whatsapp:') ? to : `whatsapp:${to}`,
    body,
  });
  return { providerId: msg.sid };
}

// SMS fallback
export async function sendSMS({ to, body }) {
  const c = getClient();
  if (!c) throw new Error('Twilio not configured');
  const msg = await c.messages.create({ from: config.twilio.smsFrom, to, body });
  return { providerId: msg.sid };
}
