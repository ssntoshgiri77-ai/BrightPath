import { query } from '../config/db.js';
import { sendEmail } from './emailService.js';
import { sendWhatsApp, sendSMS } from './whatsappService.js';

const MAX_ATTEMPTS = 3;

async function dispatch(channel, recipient, subject, body) {
  switch (channel) {
    case 'email':    return sendEmail({ to: recipient, subject, html: body, text: body });
    case 'whatsapp': return sendWhatsApp({ to: recipient, body });
    case 'sms':      return sendSMS({ to: recipient, body });
    default: throw new Error(`Unknown channel ${channel}`);
  }
}

// Send one queued notification row, with retry accounting + delivery tracking
export async function sendLog(logRow, subject, body) {
  let attempts = logRow.attempts || 0;
  try {
    attempts += 1;
    const { providerId } = await dispatch(logRow.channel, logRow.recipient, subject, body);
    await query(
      `UPDATE notification_logs SET status='sent', provider_id=$1, attempts=$2, sent_at=now(), error=NULL WHERE id=$3`,
      [providerId, attempts, logRow.id]
    );
    return true;
  } catch (e) {
    const status = attempts >= MAX_ATTEMPTS ? 'failed' : 'retrying';
    await query(
      `UPDATE notification_logs SET status=$1, attempts=$2, error=$3 WHERE id=$4`,
      [status, attempts, e.message, logRow.id]
    );
    return false;
  }
}

// Retry all failed/retrying notifications (call from a cron/worker)
export async function retryFailed(schoolId) {
  const { rows } = await query(
    `SELECT nl.*, a.title, a.body FROM notification_logs nl
     LEFT JOIN announcements a ON a.id = nl.announcement_id
     WHERE nl.school_id=$1 AND nl.status IN ('failed','retrying') AND nl.attempts < $2`,
    [schoolId, MAX_ATTEMPTS]
  );
  let ok = 0;
  for (const r of rows) {
    if (await sendLog(r, r.title || 'Notification', r.body || '')) ok += 1;
  }
  return { retried: rows.length, succeeded: ok };
}

// Resolve recipients for an announcement audience
export async function resolveRecipients(schoolId, audience, targetClassId, targetSectionId) {
  let sql = `SELECT s.id AS student_id, s.parent_email AS email, s.phone
             FROM students s WHERE s.school_id=$1 AND s.is_active=TRUE`;
  const params = [schoolId];
  if (audience === 'class' && targetClassId) {
    sql += ` AND s.current_section_id IN (SELECT id FROM sections WHERE class_id=$2)`;
    params.push(targetClassId);
  } else if (audience === 'section' && targetSectionId) {
    sql += ` AND s.current_section_id=$2`;
    params.push(targetSectionId);
  }
  const { rows } = await query(sql, params);
  return rows;
}
