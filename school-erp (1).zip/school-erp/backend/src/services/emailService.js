import nodemailer from 'nodemailer';
import { config } from '../config/index.js';

let transporter = null;
function getTransporter() {
  if (transporter) return transporter;
  transporter = nodemailer.createTransport({
    host: config.smtp.host,
    port: config.smtp.port,
    secure: config.smtp.port === 465,
    auth: config.smtp.user ? { user: config.smtp.user, pass: config.smtp.pass } : undefined,
  });
  return transporter;
}

export async function sendEmail({ to, subject, html, text, attachments }) {
  const t = getTransporter();
  const info = await t.sendMail({
    from: config.smtp.from, to, subject, text, html, attachments,
  });
  return { providerId: info.messageId };
}
