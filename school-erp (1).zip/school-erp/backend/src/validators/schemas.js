import { z } from 'zod';

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

export const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  fullName: z.string().min(2),
  role: z.enum(['admin','teacher','student','parent']),
  phone: z.string().optional(),
});

export const studentSchema = z.object({
  admissionNo: z.string().min(1),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  dateOfBirth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  gender: z.string().optional(),
  parentEmail: z.string().email().optional(),
  phone: z.string().optional(),
  sectionId: z.number().int().optional(),
  admissionDate: z.string().optional(),
});

export const publicLookupSchema = z.object({
  schoolCode: z.string().min(1),
  lastName: z.string().min(1),
  dateOfBirth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  requireOtp: z.boolean().optional(),
});
