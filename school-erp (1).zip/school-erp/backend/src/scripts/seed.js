import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { pool } from '../config/db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function run() {
  const seed = fs.readFileSync(path.resolve(__dirname, '../../../database/seed.sql'), 'utf8');
  await pool.query(seed);
  console.log('✅ Seed data inserted');
  await pool.end();
}
run().catch(e => { console.error(e); process.exit(1); });
