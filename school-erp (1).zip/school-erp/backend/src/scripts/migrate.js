import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { pool } from '../config/db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function run() {
  const schema = fs.readFileSync(path.resolve(__dirname, '../../../database/schema.sql'), 'utf8');
  await pool.query(schema);
  console.log('✅ Schema applied');
  await pool.end();
}
run().catch(e => { console.error(e); process.exit(1); });
