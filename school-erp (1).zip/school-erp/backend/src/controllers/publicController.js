import { query } from '../config/db.js';
import { generateOtp, verifyOtp } from '../services/otpService.js';
import { asyncHandler } from '../utils/asyncHandler.js';

// Step 1: look up student by last name + DOB (no login). Returns masked candidates + triggers OTP.
export const publicLookup = asyncHandler(async (req, res) => {
  const { schoolCode, lastName, dateOfBirth, requireOtp } = req.body;
  const { rows: schoolRows } = await query(`SELECT id FROM schools WHERE code=$1 AND is_active=TRUE`, [schoolCode]);
  if (!schoolRows.length) return res.status(404).json({ error: 'School not found' });
  const schoolId = schoolRows[0].id;

  const { rows } = await query(
    `SELECT s.id, s.first_name, s.last_name, s.admission_no, s.parent_email
     FROM students s
     WHERE s.school_id=$1 AND lower(s.last_name)=lower($2) AND s.date_of_birth=$3 AND s.deleted_at IS NULL`,
    [schoolId, lastName, dateOfBirth]);
  if (!rows.length) return res.status(404).json({ error: 'No matching student found' });

  if (requireOtp) {
    const candidate = rows[0];
    const identifier = candidate.parent_email;
    if (!identifier) return res.status(400).json({ error: 'No contact on file for OTP' });
    const otp = await generateOtp(schoolId, identifier);
    return res.json({
      requireOtp: true, schoolId,
      maskedContact: identifier.replace(/(.{2}).*(@.*)/, '$1***$2'),
      candidates: rows.map(r => ({ id: r.id, name: `${r.first_name} ${r.last_name}`, admissionNo: r.admission_no })),
      ...(otp.devCode ? { devCode: otp.devCode } : {}),
    });
  }
  res.json({
    requireOtp: false, schoolId,
    candidates: rows.map(r => ({ id: r.id, name: `${r.first_name} ${r.last_name}`, admissionNo: r.admission_no })),
  });
});

// Step 2: (optional) verify OTP then return published results
export const publicResult = asyncHandler(async (req, res) => {
  const { schoolId, studentId, examId, otp } = req.body;

  // Verify OTP against the contact on file (identifier derived server-side, never trusted from client)
  if (otp) {
    const { rows: contact } = await query(
      `SELECT parent_email FROM students WHERE id=$1 AND school_id=$2`, [studentId, schoolId]);
    const identifier = contact[0]?.parent_email;
    if (!identifier) return res.status(400).json({ error: 'No contact on file for OTP' });
    const ok = await verifyOtp(schoolId, identifier, otp);
    if (!ok) return res.status(401).json({ error: 'Invalid or expired OTP' });
  }

  // Only expose PUBLISHED results
  const { rows: pub } = await query(
    `SELECT rp.id FROM result_publish rp
     JOIN students s ON s.current_section_id=rp.section_id
     WHERE rp.exam_id=$1 AND s.id=$2 AND rp.school_id=$3`, [examId, studentId, schoolId]);
  if (!pub.length) return res.status(403).json({ error: 'Results not published yet' });

  const { rows: rc } = await query(
    `SELECT rc.*, e.name AS exam_name, s.first_name, s.last_name, s.admission_no,
            c.name AS class_name, sec.name AS section_name
     FROM report_cards rc
     JOIN exams e ON e.id=rc.exam_id
     JOIN students s ON s.id=rc.student_id
     JOIN sections sec ON sec.id=s.current_section_id
     JOIN classes c ON c.id=sec.class_id
     WHERE rc.exam_id=$1 AND rc.student_id=$2 AND rc.school_id=$3`, [examId, studentId, schoolId]);
  if (!rc.length) return res.status(404).json({ error: 'Result not found' });

  const { rows: subjects } = await query(
    `SELECT sub.name, es.max_marks, m.marks_obtained, m.grade
     FROM marks m JOIN exam_subjects es ON es.id=m.exam_subject_id
     JOIN subjects sub ON sub.id=es.subject_id
     WHERE es.exam_id=$1 AND m.student_id=$2 ORDER BY sub.name`, [examId, studentId]);

  res.json({ report: rc[0], subjects, pdfUrl: rc[0].pdf_url });
});

// List published exams for a school (for the public portal dropdown)
export const publicExams = asyncHandler(async (req, res) => {
  const { rows: schoolRows } = await query(`SELECT id FROM schools WHERE code=$1`, [req.query.schoolCode]);
  if (!schoolRows.length) return res.json([]);
  const { rows } = await query(
    `SELECT DISTINCT e.id, e.name FROM exams e
     JOIN result_publish rp ON rp.exam_id=e.id
     WHERE e.school_id=$1 ORDER BY e.id DESC`, [schoolRows[0].id]);
  res.json(rows);
});
