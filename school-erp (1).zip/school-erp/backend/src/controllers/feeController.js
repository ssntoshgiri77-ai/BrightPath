import { query, withTx } from '../config/db.js';
import { audit } from '../utils/audit.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const createFeeStructure = asyncHandler(async (req, res) => {
  const { academicYearId, name, classId, amount, dueDate } = req.body;
  const { rows } = await query(
    `INSERT INTO fee_structures (school_id,academic_year_id,name,class_id,amount,due_date)
     VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
    [req.user.schoolId, academicYearId, name, classId || null, amount, dueDate || null]);
  res.status(201).json(rows[0]);
});

// Assign a fee structure to all students in a class (or a specific list)
export const assignFees = asyncHandler(async (req, res) => {
  const { feeStructureId, classId, studentIds } = req.body;
  const schoolId = req.user.schoolId;
  const { rows: fs } = await query(`SELECT amount, due_date FROM fee_structures WHERE id=$1 AND school_id=$2`, [feeStructureId, schoolId]);
  if (!fs.length) return res.status(404).json({ error: 'Fee structure not found' });

  let targets = studentIds;
  if (!targets && classId) {
    const { rows } = await query(
      `SELECT id FROM students WHERE school_id=$1 AND current_section_id IN (SELECT id FROM sections WHERE class_id=$2) AND deleted_at IS NULL`,
      [schoolId, classId]);
    targets = rows.map(r => r.id);
  }
  for (const sid of targets) {
    await query(
      `INSERT INTO student_fees (school_id,student_id,fee_structure_id,amount_due,due_date,status)
       VALUES ($1,$2,$3,$4,$5,'pending')
       ON CONFLICT (student_id,fee_structure_id) DO NOTHING`,
      [schoolId, sid, feeStructureId, fs[0].amount, fs[0].due_date]);
  }
  res.json({ assigned: targets.length });
});

// Record a payment; balance + status auto-updated
export const recordPayment = asyncHandler(async (req, res) => {
  const { studentFeeId, amount, method, referenceNo } = req.body;
  const schoolId = req.user.schoolId;
  const result = await withTx(async (client) => {
    await client.query(
      `INSERT INTO payments (school_id,student_fee_id,amount,method,reference_no,recorded_by)
       VALUES ($1,$2,$3,$4,$5,$6)`, [schoolId, studentFeeId, amount, method || null, referenceNo || null, req.user.id]);
    const { rows } = await client.query(
      `UPDATE student_fees sf SET
         amount_paid = amount_paid + $1,
         status = CASE
           WHEN amount_paid + $1 >= amount_due THEN 'paid'::payment_status
           WHEN amount_paid + $1 > 0 THEN 'partial'::payment_status
           ELSE 'pending'::payment_status END
       WHERE id=$2 AND school_id=$3
       RETURNING amount_due, amount_paid, (amount_due - amount_paid) AS balance, status`,
      [amount, studentFeeId, schoolId]);
    return rows[0];
  });
  await audit({ schoolId, actorId: req.user.id, action: 'FEE_PAYMENT', entity: 'student_fees', entityId: studentFeeId, metadata: { amount }, ip: req.ip });
  res.json(result);
});

export const studentFees = asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT sf.*, fs.name AS fee_name, (sf.amount_due - sf.amount_paid) AS balance
     FROM student_fees sf JOIN fee_structures fs ON fs.id=sf.fee_structure_id
     WHERE sf.student_id=$1 AND sf.school_id=$2 ORDER BY sf.due_date`,
    [req.params.studentId, req.user.schoolId]);
  res.json(rows);
});

// Fee collection report
export const feeReport = asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT
       COUNT(*)                             AS total_records,
       COALESCE(SUM(amount_due),0)          AS total_due,
       COALESCE(SUM(amount_paid),0)         AS total_collected,
       COALESCE(SUM(amount_due-amount_paid),0) AS total_outstanding,
       COUNT(*) FILTER (WHERE status='paid')    AS paid_count,
       COUNT(*) FILTER (WHERE status='partial') AS partial_count,
       COUNT(*) FILTER (WHERE status='pending') AS pending_count
     FROM student_fees WHERE school_id=$1`, [req.user.schoolId]);
  res.json(rows[0]);
});
