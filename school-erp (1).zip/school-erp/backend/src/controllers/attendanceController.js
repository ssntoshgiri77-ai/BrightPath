import { query } from '../config/db.js';
import { audit } from '../utils/audit.js';
import { asyncHandler } from '../utils/asyncHandler.js';

// Bulk mark attendance for a section on a date
export const markAttendance = asyncHandler(async (req, res) => {
  const { sectionId, date, records } = req.body; // records: [{studentId,status,remarks}]
  const schoolId = req.user.schoolId;
  const values = [];
  const params = [];
  records.forEach((r, i) => {
    const b = i * 6;
    params.push(schoolId, r.studentId, sectionId, date, r.status, req.user.id);
    values.push(`($${b+1},$${b+2},$${b+3},$${b+4},$${b+5},$${b+6})`);
  });
  await query(
    `INSERT INTO attendance (school_id,student_id,section_id,att_date,status,marked_by)
     VALUES ${values.join(',')}
     ON CONFLICT (student_id,att_date)
     DO UPDATE SET status=EXCLUDED.status, marked_by=EXCLUDED.marked_by`, params);
  await audit({ schoolId, actorId: req.user.id, action: 'ATTENDANCE_MARK', entity: 'attendance', metadata: { sectionId, date, count: records.length }, ip: req.ip });
  res.json({ marked: records.length });
});

export const sectionAttendance = asyncHandler(async (req, res) => {
  const { sectionId, date } = req.query;
  const { rows } = await query(
    `SELECT s.id AS student_id, s.first_name, s.last_name, a.status, a.remarks
     FROM students s
     LEFT JOIN attendance a ON a.student_id=s.id AND a.att_date=$2
     WHERE s.current_section_id=$1 AND s.deleted_at IS NULL ORDER BY s.first_name`,
    [sectionId, date]);
  res.json(rows);
});

// Attendance analytics (% present) per student
export const studentAttendanceStats = asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT
       COUNT(*)                                             AS total,
       COUNT(*) FILTER (WHERE status='present')             AS present,
       COUNT(*) FILTER (WHERE status='absent')              AS absent,
       COUNT(*) FILTER (WHERE status='late')                AS late,
       ROUND(100.0 * COUNT(*) FILTER (WHERE status IN ('present','late')) / NULLIF(COUNT(*),0), 1) AS percentage
     FROM attendance WHERE student_id=$1`, [req.params.studentId]);
  res.json(rows[0]);
});
