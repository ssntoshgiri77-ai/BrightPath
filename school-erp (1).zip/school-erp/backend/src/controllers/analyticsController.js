import { query } from '../config/db.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const dashboardSummary = asyncHandler(async (req, res) => {
  const schoolId = req.user.schoolId;
  const [students, teachers, classes, fees] = await Promise.all([
    query(`SELECT COUNT(*) FROM students WHERE school_id=$1 AND deleted_at IS NULL`, [schoolId]),
    query(`SELECT COUNT(*) FROM users WHERE school_id=$1 AND role='teacher'`, [schoolId]),
    query(`SELECT COUNT(*) FROM classes WHERE school_id=$1`, [schoolId]),
    query(`SELECT COALESCE(SUM(amount_paid),0) collected, COALESCE(SUM(amount_due-amount_paid),0) outstanding FROM student_fees WHERE school_id=$1`, [schoolId]),
  ]);
  res.json({
    students: +students.rows[0].count,
    teachers: +teachers.rows[0].count,
    classes: +classes.rows[0].count,
    feesCollected: +fees.rows[0].collected,
    feesOutstanding: +fees.rows[0].outstanding,
  });
});

// Performance trend: avg percentage per exam
export const performanceTrends = asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT e.name AS exam, ROUND(AVG(rc.percentage),1) AS avg_percentage, COUNT(*) AS students
     FROM report_cards rc JOIN exams e ON e.id=rc.exam_id
     WHERE rc.school_id=$1 GROUP BY e.id, e.name ORDER BY e.id`, [req.user.schoolId]);
  res.json(rows);
});

// Attendance overview per section
export const attendanceOverview = asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT c.name AS class_name, sec.name AS section_name,
       ROUND(100.0 * COUNT(*) FILTER (WHERE a.status IN ('present','late')) / NULLIF(COUNT(*),0),1) AS attendance_pct
     FROM attendance a
     JOIN sections sec ON sec.id=a.section_id
     JOIN classes c ON c.id=sec.class_id
     WHERE a.school_id=$1 GROUP BY c.name, sec.name ORDER BY c.name, sec.name`, [req.user.schoolId]);
  res.json(rows);
});

export const auditLogs = asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT al.*, u.full_name AS actor_name FROM audit_logs al
     LEFT JOIN users u ON u.id=al.actor_id
     WHERE al.school_id=$1 ORDER BY al.created_at DESC LIMIT 200`, [req.user.schoolId]);
  res.json(rows);
});
