import { query } from '../config/db.js';
import { hashPassword, verifyPassword } from '../utils/password.js';
import { signAccessToken, signRefreshToken } from '../utils/jwt.js';
import { audit } from '../utils/audit.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const { rows } = await query(
    `SELECT * FROM users WHERE email=$1 AND is_active=TRUE AND deleted_at IS NULL LIMIT 1`, [email]);
  const user = rows[0];
  if (!user || !(await verifyPassword(password, user.password_hash))) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  await query(`UPDATE users SET last_login_at=now() WHERE id=$1`, [user.id]);
  const payload = { id: user.id, role: user.role, schoolId: user.school_id, email: user.email };
  await audit({ schoolId: user.school_id, actorId: user.id, action: 'LOGIN', entity: 'users', entityId: user.id, ip: req.ip });
  res.json({
    accessToken: signAccessToken(payload),
    refreshToken: signRefreshToken(payload),
    user: { id: user.id, role: user.role, fullName: user.full_name, email: user.email, schoolId: user.school_id },
  });
});

export const me = asyncHandler(async (req, res) => {
  const { rows } = await query(`SELECT id, full_name, email, role, school_id FROM users WHERE id=$1`, [req.user.id]);
  res.json(rows[0] || null);
});

export const register = asyncHandler(async (req, res) => {
  const { email, password, fullName, role, phone } = req.body;
  const schoolId = req.user.schoolId;
  const hash = await hashPassword(password);
  const { rows } = await query(
    `INSERT INTO users (school_id,email,phone,password_hash,role,full_name)
     VALUES ($1,$2,$3,$4,$5,$6)
     RETURNING id, email, role, full_name`,
    [schoolId, email, phone || null, hash, role, fullName]);
  await audit({ schoolId, actorId: req.user.id, action: 'USER_CREATE', entity: 'users', entityId: rows[0].id, metadata: { role }, ip: req.ip });
  res.status(201).json(rows[0]);
});
