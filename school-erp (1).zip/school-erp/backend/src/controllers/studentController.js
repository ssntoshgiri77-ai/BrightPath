import { query, withTx } from '../config/db.js';
import { audit } from '../utils/audit.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const listStudents = asyncHandler(async (req, res) => {
  const { sectionId, search } = req.query;
  const params = [req.user.schoolId];
  let sql = `SELECT s.*, c.name AS class_name, sec.name AS section_name
             FROM students s
             LEFT JOIN sections sec ON sec.id=s.current_section_id
             LEFT JOIN classes c ON c.id=sec.class_id
             WHERE s.school_id=$1 AND s.deleted_at IS NULL`;
  if (sectionId) { params.push(sectionId); sql += ` AND s.current_section_id=$${params.length}`; }
  if (search)    { params.push(`%${search}%`); sql += ` AND (s.first_name ILIKE $${params.length} OR s.last_name ILIKE $${params.length} OR s.admission_no ILIKE $${params.length})`; }
  sql += ` ORDER BY s.first_name LIMIT 500`;
  const { rows } = await query(sql, params);
  res.json(rows);
});

export const getStudent = asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT s.*, c.name AS class_name, sec.name AS section_name
     FROM students s
     LEFT JOIN sections sec ON sec.id=s.current_section_id
     LEFT JOIN classes c ON c.id=sec.class_id
     WHERE s.id=$1 AND s.school_id=$2`, [req.params.id, req.user.schoolId]);
  if (!rows.length) return res.status(404).json({ error: 'Student not found' });
  res.json(rows[0]);
});

// Admission
export const createStudent = asyncHandler(async (req, res) => {
  const b = req.body;
  const schoolId = req.user.schoolId;
  const { rows } = await query(
    `INSERT INTO students (school_id,admission_no,first_name,last_name,date_of_birth,gender,parent_email,phone,current_section_id,admission_date)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,COALESCE($10,CURRENT_DATE)) RETURNING *`,
    [schoolId, b.admissionNo, b.firstName, b.lastName, b.dateOfBirth, b.gender || null,
     b.parentEmail || null, b.phone || null, b.sectionId || null, b.admissionDate || null]);
  await audit({ schoolId, actorId: req.user.id, action: 'STUDENT_ADMIT', entity: 'students', entityId: rows[0].id, ip: req.ip });
  res.status(201).json(rows[0]);
});

export const updateStudent = asyncHandler(async (req, res) => {
  const b = req.body;
  const { rows } = await query(
    `UPDATE students SET first_name=COALESCE($1,first_name), last_name=COALESCE($2,last_name),
       date_of_birth=COALESCE($3,date_of_birth), gender=COALESCE($4,gender),
       parent_email=COALESCE($5,parent_email), phone=COALESCE($6,phone),
       current_section_id=COALESCE($7,current_section_id)
     WHERE id=$8 AND school_id=$9 RETURNING *`,
    [b.firstName, b.lastName, b.dateOfBirth, b.gender, b.parentEmail, b.phone, b.sectionId,
     req.params.id, req.user.schoolId]);
  if (!rows.length) return res.status(404).json({ error: 'Student not found' });
  res.json(rows[0]);
});

// Class promotion with history tracking
export const promoteStudents = asyncHandler(async (req, res) => {
  const { studentIds, toSectionId, academicYearId, result } = req.body;
  const schoolId = req.user.schoolId;
  await withTx(async (client) => {
    for (const sid of studentIds) {
      const { rows } = await client.query(`SELECT current_section_id FROM students WHERE id=$1 AND school_id=$2`, [sid, schoolId]);
      const from = rows[0]?.current_section_id || null;
      await client.query(`UPDATE students SET current_section_id=$1 WHERE id=$2 AND school_id=$3`, [toSectionId, sid, schoolId]);
      await client.query(
        `INSERT INTO student_class_history (student_id,section_id,academic_year_id,promoted_from_section_id,result)
         VALUES ($1,$2,$3,$4,$5)`, [sid, toSectionId, academicYearId, from, result || 'promoted']);
    }
  });
  await audit({ schoolId, actorId: req.user.id, action: 'STUDENT_PROMOTE', entity: 'students', metadata: { count: studentIds.length, toSectionId }, ip: req.ip });
  res.json({ promoted: studentIds.length });
});
