import { query } from '../config/db.js';
import { audit } from '../utils/audit.js';
import { gradeFor } from '../utils/grades.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const listExams = asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT * FROM exams WHERE school_id=$1 ORDER BY created_at DESC`, [req.user.schoolId]);
  res.json(rows);
});

export const createExam = asyncHandler(async (req, res) => {
  const { name, academicYearId, startDate, endDate } = req.body;
  const { rows } = await query(
    `INSERT INTO exams (school_id,academic_year_id,name,exam_date_start,exam_date_end,status,created_by)
     VALUES ($1,$2,$3,$4,$5,'draft',$6) RETURNING *`,
    [req.user.schoolId, academicYearId, name, startDate || null, endDate || null, req.user.id]);
  await audit({ schoolId: req.user.schoolId, actorId: req.user.id, action: 'EXAM_CREATE', entity: 'exams', entityId: rows[0].id, ip: req.ip });
  res.status(201).json(rows[0]);
});

// Configure subjects (with max/pass marks) for an exam+section
export const configureExamSubjects = asyncHandler(async (req, res) => {
  const { examId } = req.params;
  const { sectionId, subjects } = req.body; // subjects: [{subjectId,maxMarks,passMarks}]
  for (const s of subjects) {
    await query(
      `INSERT INTO exam_subjects (exam_id,subject_id,section_id,max_marks,pass_marks)
       VALUES ($1,$2,$3,$4,$5)
       ON CONFLICT (exam_id,subject_id,section_id)
       DO UPDATE SET max_marks=EXCLUDED.max_marks, pass_marks=EXCLUDED.pass_marks`,
      [examId, s.subjectId, sectionId, s.maxMarks || 100, s.passMarks || 35]);
  }
  await query(`UPDATE exams SET status='marks_entry' WHERE id=$1 AND status='draft'`, [examId]);
  res.json({ configured: subjects.length });
});

// Enter marks (blocked when locked/published)
export const enterMarks = asyncHandler(async (req, res) => {
  const { examSubjectId, marks } = req.body; // marks: [{studentId,marksObtained,isAbsent}]
  const es = await query(
    `SELECT es.max_marks, e.status FROM exam_subjects es
     JOIN exams e ON e.id=es.exam_id WHERE es.id=$1`, [examSubjectId]);
  if (!es.rows.length) return res.status(404).json({ error: 'Exam subject not found' });
  if (['locked','published'].includes(es.rows[0].status))
    return res.status(423).json({ error: 'Marks are locked and cannot be edited' });

  const max = Number(es.rows[0].max_marks);
  for (const m of marks) {
    const pct = max ? (Number(m.marksObtained) / max) * 100 : 0;
    await query(
      `INSERT INTO marks (exam_subject_id,student_id,marks_obtained,grade,is_absent,entered_by)
       VALUES ($1,$2,$3,$4,$5,$6)
       ON CONFLICT (exam_subject_id,student_id)
       DO UPDATE SET marks_obtained=EXCLUDED.marks_obtained, grade=EXCLUDED.grade,
                     is_absent=EXCLUDED.is_absent, entered_by=EXCLUDED.entered_by
       WHERE marks.is_locked=FALSE`,
      [examSubjectId, m.studentId, m.marksObtained || 0, gradeFor(pct), !!m.isAbsent, req.user.id]);
  }
  res.json({ saved: marks.length });
});

export const getExamSubjectMarks = asyncHandler(async (req, res) => {
  const { examSubjectId } = req.params;
  const { rows } = await query(
    `SELECT s.id AS student_id, s.first_name, s.last_name, m.marks_obtained, m.grade, m.is_absent, m.is_locked
     FROM exam_subjects es
     JOIN students s ON s.current_section_id=es.section_id AND s.deleted_at IS NULL
     LEFT JOIN marks m ON m.exam_subject_id=es.id AND m.student_id=s.id
     WHERE es.id=$1 ORDER BY s.first_name`, [examSubjectId]);
  res.json(rows);
});
