import { query } from '../config/db.js';
import { audit } from '../utils/audit.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { resolveRecipients, sendLog, retryFailed } from '../services/notificationService.js';

// Create + (optionally) immediately send an announcement across channels
export const createAnnouncement = asyncHandler(async (req, res) => {
  const b = req.body;
  const schoolId = req.user.schoolId;
  const { rows } = await query(
    `INSERT INTO announcements (school_id,title,body,audience,target_class_id,target_section_id,channels,is_emergency,scheduled_at,created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [schoolId, b.title, b.body, b.audience || 'all', b.targetClassId || null, b.targetSectionId || null,
     b.channels || ['email'], !!b.isEmergency, b.scheduledAt || null, req.user.id]);
  const ann = rows[0];
  await audit({ schoolId, actorId: req.user.id, action: 'ANNOUNCEMENT_CREATE', entity: 'announcements', entityId: ann.id, ip: req.ip });

  // If not scheduled for later, dispatch now
  if (!b.scheduledAt) {
    const summary = await dispatchAnnouncement(schoolId, ann);
    return res.status(201).json({ announcement: ann, ...summary });
  }
  res.status(201).json({ announcement: ann, scheduled: true });
});

export async function dispatchAnnouncement(schoolId, ann) {
  const recipients = await resolveRecipients(schoolId, ann.audience, ann.target_class_id, ann.target_section_id);
  const channels = ann.channels || ['email'];
  let queued = 0;
  const logs = [];
  for (const r of recipients) {
    for (const ch of channels) {
      const recipient = ch === 'email' ? r.email : r.phone;
      if (!recipient) continue;
      const { rows } = await query(
        `INSERT INTO notification_logs (school_id,announcement_id,student_id,recipient,channel,status)
         VALUES ($1,$2,$3,$4,$5,'queued') RETURNING *`,
        [schoolId, ann.id, r.student_id, recipient, ch]);
      logs.push(rows[0]); queued++;
    }
  }
  // fire off delivery (sequential; use a worker/queue for scale)
  let sent = 0;
  for (const log of logs) {
    if (await sendLog(log, ann.title, ann.body)) sent++;
  }
  await query(`UPDATE announcements SET sent_at=now() WHERE id=$1`, [ann.id]);
  return { queued, sent, failed: queued - sent };
}

export const listAnnouncements = asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT a.*,
       (SELECT COUNT(*) FROM notification_logs nl WHERE nl.announcement_id=a.id) AS total,
       (SELECT COUNT(*) FROM notification_logs nl WHERE nl.announcement_id=a.id AND nl.status='sent') AS sent,
       (SELECT COUNT(*) FROM notification_logs nl WHERE nl.announcement_id=a.id AND nl.status='failed') AS failed
     FROM announcements a WHERE a.school_id=$1 ORDER BY a.created_at DESC LIMIT 100`, [req.user.schoolId]);
  res.json(rows);
});

export const notificationLogs = asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT * FROM notification_logs WHERE announcement_id=$1 AND school_id=$2 ORDER BY id`,
    [req.params.announcementId, req.user.schoolId]);
  res.json(rows);
});

export const retryNotifications = asyncHandler(async (req, res) => {
  const result = await retryFailed(req.user.schoolId);
  res.json(result);
});
