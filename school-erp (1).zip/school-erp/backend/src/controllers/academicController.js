import { query } from '../config/db.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const listClasses = asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT c.*, json_agg(json_build_object('id',s.id,'name',s.name,'classTeacherId',s.class_teacher_id)
       ORDER BY s.name) FILTER (WHERE s.id IS NOT NULL) AS sections
     FROM classes c LEFT JOIN sections s ON s.class_id=c.id
     WHERE c.school_id=$1 GROUP BY c.id ORDER BY c.grade_level`, [req.user.schoolId]);
  res.json(rows);
});

export const createClass = asyncHandler(async (req, res) => {
  const { name, gradeLevel } = req.body;
  const { rows } = await query(
    `INSERT INTO classes (school_id,name,grade_level) VALUES ($1,$2,$3) RETURNING *`,
    [req.user.schoolId, name, gradeLevel || null]);
  res.status(201).json(rows[0]);
});

export const createSection = asyncHandler(async (req, res) => {
  const { classId, name, classTeacherId } = req.body;
  const { rows } = await query(
    `INSERT INTO sections (class_id,name,class_teacher_id) VALUES ($1,$2,$3) RETURNING *`,
    [classId, name, classTeacherId || null]);
  res.status(201).json(rows[0]);
});

export const listSubjects = asyncHandler(async (req, res) => {
  const { rows } = await query(`SELECT * FROM subjects WHERE school_id=$1 ORDER BY name`, [req.user.schoolId]);
  res.json(rows);
});

export const createSubject = asyncHandler(async (req, res) => {
  const { name, code } = req.body;
  const { rows } = await query(
    `INSERT INTO subjects (school_id,name,code) VALUES ($1,$2,$3) RETURNING *`,
    [req.user.schoolId, name, code]);
  res.status(201).json(rows[0]);
});

export const assignTeacher = asyncHandler(async (req, res) => {
  const { teacherId, sectionId, subjectId } = req.body;
  const { rows } = await query(
    `INSERT INTO teacher_assignments (school_id,teacher_id,section_id,subject_id)
     VALUES ($1,$2,$3,$4)
     ON CONFLICT (section_id,subject_id,teacher_id) DO NOTHING RETURNING *`,
    [req.user.schoolId, teacherId, sectionId, subjectId]);
  res.status(201).json(rows[0] || { message: 'Already assigned' });
});
