import { query, withTx } from '../config/db.js';
import { audit } from '../utils/audit.js';
import { gradeFor, remarkFor } from '../utils/grades.js';
import { generateReportCard } from '../services/pdfService.js';
import { sendEmail } from '../services/emailService.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import path from 'path';

// Compute + persist report cards, then rank students within the section
async function buildReportCards(client, schoolId, examId, sectionId) {
  // Aggregate totals per student for this exam+section
  const { rows: agg } = await client.query(
    `SELECT m.student_id,
            SUM(m.marks_obtained)       AS total,
            SUM(es.max_marks)           AS max_total
     FROM marks m
     JOIN exam_subjects es ON es.id=m.exam_subject_id
     WHERE es.exam_id=$1 AND es.section_id=$2
     GROUP BY m.student_id`, [examId, sectionId]);

  const computed = agg.map(r => {
    const pct = r.max_total ? (Number(r.total) / Number(r.max_total)) * 100 : 0;
    return { studentId: r.student_id, total: Number(r.total), maxTotal: Number(r.max_total),
             percentage: +pct.toFixed(2), grade: gradeFor(pct) };
  }).sort((a, b) => b.percentage - a.percentage);

  computed.forEach((c, i) => { c.rank = i + 1; });

  for (const c of computed) {
    await client.query(
      `INSERT INTO report_cards (school_id,exam_id,student_id,total_marks,max_total,percentage,overall_grade,rank_in_section,remarks)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       ON CONFLICT (exam_id,student_id) DO UPDATE SET
         total_marks=EXCLUDED.total_marks, max_total=EXCLUDED.max_total,
         percentage=EXCLUDED.percentage, overall_grade=EXCLUDED.overall_grade,
         rank_in_section=EXCLUDED.rank_in_section, remarks=EXCLUDED.remarks`,
      [schoolId, examId, c.studentId, c.total, c.maxTotal, c.percentage, c.grade, c.rank, remarkFor(c.percentage)]);
  }
  return computed;
}

// ADMIN: publish results for a section -> lock marks, generate PDFs, notify parents
export const publishResults = asyncHandler(async (req, res) => {
  const { examId } = req.params;
  const { sectionId } = req.body;
  const schoolId = req.user.schoolId;

  const computed = await withTx(async (client) => {
    // 1. lock all marks for this exam+section
    await client.query(
      `UPDATE marks SET is_locked=TRUE
       WHERE exam_subject_id IN (SELECT id FROM exam_subjects WHERE exam_id=$1 AND section_id=$2)`,
      [examId, sectionId]);
    // 2. build report cards + ranks
    const computed = await buildReportCards(client, schoolId, examId, sectionId);
    // 3. record publish + set exam status
    await client.query(
      `INSERT INTO result_publish (school_id,exam_id,section_id,published_by)
       VALUES ($1,$2,$3,$4) ON CONFLICT (exam_id,section_id) DO NOTHING`,
      [schoolId, examId, sectionId, req.user.id]);
    await client.query(`UPDATE exams SET status='published' WHERE id=$1`, [examId]);
    return computed;
  });

  await audit({ schoolId, actorId: req.user.id, action: 'RESULT_PUBLISH', entity: 'exams', entityId: examId, metadata: { sectionId, students: computed.length }, ip: req.ip });

  // 4. generate PDFs + email parents (best-effort, outside the txn)
  const notify = [];
  for (const c of computed) {
    try {
      const data = await assembleReportCardData(schoolId, examId, c.studentId);
      const { publicUrl, filePath } = await generateReportCard(data);
      await query(`UPDATE report_cards SET pdf_url=$1 WHERE exam_id=$2 AND student_id=$3`, [publicUrl, examId, c.studentId]);
      if (data.student.parentEmail) {
        await sendEmail({
          to: data.student.parentEmail,
          subject: `${data.exam.name} Result — ${data.student.fullName}`,
          html: `<p>Dear Parent,</p><p>The result for <b>${data.student.fullName}</b> has been published.</p>
                 <p>Percentage: <b>${c.percentage}%</b> | Grade: <b>${c.grade}</b> | Rank: <b>${c.rank}</b></p>
                 <p>Download the report card: <a href="${publicUrl}">${publicUrl}</a></p>`,
          attachments: [{ filename: path.basename(filePath), path: filePath }],
        });
        notify.push(data.student.parentEmail);
      }
    } catch (e) { console.error('report/notify failed for student', c.studentId, e.message); }
  }
  await query(`UPDATE result_publish SET notify_sent=TRUE WHERE exam_id=$1 AND section_id=$2`, [examId, sectionId]);

  res.json({ published: computed.length, notified: notify.length });
});

// Build the data object needed by the PDF generator
export async function assembleReportCardData(schoolId, examId, studentId) {
  const { rows: sRows } = await query(
    `SELECT s.*, c.name AS class_name, sec.name AS section_name, sec.class_teacher_id,
            sch.name AS school_name, sch.address, sch.logo_url, sch.principal_signature_url
     FROM students s
     JOIN sections sec ON sec.id=s.current_section_id
     JOIN classes c ON c.id=sec.class_id
     JOIN schools sch ON sch.id=s.school_id
     WHERE s.id=$1 AND s.school_id=$2`, [studentId, schoolId]);
  const s = sRows[0];
  const { rows: subjRows } = await query(
    `SELECT sub.name, es.max_marks, m.marks_obtained, m.grade
     FROM marks m JOIN exam_subjects es ON es.id=m.exam_subject_id
     JOIN subjects sub ON sub.id=es.subject_id
     WHERE es.exam_id=$1 AND m.student_id=$2 ORDER BY sub.name`, [examId, studentId]);
  const { rows: rcRows } = await query(
    `SELECT rc.*, e.name AS exam_name FROM report_cards rc JOIN exams e ON e.id=rc.exam_id
     WHERE rc.exam_id=$1 AND rc.student_id=$2`, [examId, studentId]);
  const rc = rcRows[0] || {};
  const toLocal = (u) => u && u.startsWith('http') ? null : u; // local file paths only for pdfkit
  return {
    school: { name: s.school_name, address: s.address, logoPath: toLocal(s.logo_url), principalSignaturePath: toLocal(s.principal_signature_url) },
    classTeacherSignaturePath: null,
    student: { id: s.id, fullName: `${s.first_name} ${s.last_name}`, admissionNo: s.admission_no,
               className: s.class_name, sectionName: s.section_name,
               dob: s.date_of_birth?.toISOString?.().slice(0,10) || s.date_of_birth, parentEmail: s.parent_email },
    exam: { id: examId, name: rc.exam_name || 'Examination' },
    subjects: subjRows.map(r => ({ name: r.name, maxMarks: r.max_marks, marksObtained: r.marks_obtained, grade: r.grade })),
    totals: { total: rc.total_marks, maxTotal: rc.max_total, percentage: rc.percentage, grade: rc.overall_grade, rank: rc.rank_in_section },
    remarks: rc.remarks,
  };
}

// STUDENT/PARENT/ADMIN: get a student's report card record + regenerate PDF on demand
export const getReportCard = asyncHandler(async (req, res) => {
  const { examId, studentId } = req.params;
  const { rows } = await query(
    `SELECT rc.*, e.name AS exam_name FROM report_cards rc JOIN exams e ON e.id=rc.exam_id
     WHERE rc.exam_id=$1 AND rc.student_id=$2 AND rc.school_id=$3`,
    [examId, studentId, req.user.schoolId]);
  if (!rows.length) return res.status(404).json({ error: 'Report card not available' });
  res.json(rows[0]);
});
