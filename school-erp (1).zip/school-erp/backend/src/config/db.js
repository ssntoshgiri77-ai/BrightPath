import pg from 'pg';
import { config } from './index.js';

const { Pool } = pg;

// Render (and most managed Postgres) require SSL for EXTERNAL connections.
// Set DB_SSL=true when using an external connection string.
// Internal Render connections (same region) do not need SSL -> leave DB_SSL unset.
function sslConfig() {
  if (process.env.DB_SSL === 'true') return { rejectUnauthorized: false };
  if (config.databaseUrl && /\.render\.com/.test(config.databaseUrl)) return { rejectUnauthorized: false };
  return false;
}

export const pool = new Pool({
  connectionString: config.databaseUrl,
  ssl: sslConfig(),
  max: 20,
  idleTimeoutMillis: 30000,
});

pool.on('error', (err) => console.error('Unexpected PG pool error', err));

// helper: run a query
export const query = (text, params) => pool.query(text, params);

// helper: transaction wrapper
export async function withTx(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
}
