import { Router } from 'express';
import * as c from '../controllers/announcementController.js';
import { authenticate, authorize } from '../middleware/auth.js';

const r = Router();
r.use(authenticate);
r.get('/', c.listAnnouncements);
r.post('/', authorize('admin'), c.createAnnouncement);
r.get('/:announcementId/logs', authorize('admin'), c.notificationLogs);
r.post('/retry', authorize('admin'), c.retryNotifications);
export default r;
