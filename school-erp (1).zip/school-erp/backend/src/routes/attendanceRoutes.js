import { Router } from 'express';
import * as c from '../controllers/attendanceController.js';
import { authenticate, authorize } from '../middleware/auth.js';

const r = Router();
r.use(authenticate);
r.get('/', c.sectionAttendance);
r.post('/', authorize('admin','teacher'), c.markAttendance);
r.get('/stats/:studentId', c.studentAttendanceStats);
export default r;
