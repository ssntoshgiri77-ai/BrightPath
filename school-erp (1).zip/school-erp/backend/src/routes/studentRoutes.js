import { Router } from 'express';
import * as c from '../controllers/studentController.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { studentSchema } from '../validators/schemas.js';

const r = Router();
r.use(authenticate);
r.get('/', c.listStudents);
r.get('/:id', c.getStudent);
r.post('/', authorize('admin'), validate(studentSchema), c.createStudent);
r.put('/:id', authorize('admin'), c.updateStudent);
r.post('/promote', authorize('admin'), c.promoteStudents);
export default r;
