import { Router } from 'express';
import * as c from '../controllers/examController.js';
import * as rc from '../controllers/resultController.js';
import { authenticate, authorize } from '../middleware/auth.js';

const r = Router();
r.use(authenticate);
r.get('/', c.listExams);
r.post('/', authorize('admin'), c.createExam);
r.post('/:examId/subjects', authorize('admin'), c.configureExamSubjects);
r.post('/marks', authorize('admin','teacher'), c.enterMarks);
r.get('/subject/:examSubjectId/marks', authorize('admin','teacher'), c.getExamSubjectMarks);
// results
r.post('/:examId/publish', authorize('admin'), rc.publishResults);
r.get('/:examId/report-card/:studentId', rc.getReportCard);
export default r;
