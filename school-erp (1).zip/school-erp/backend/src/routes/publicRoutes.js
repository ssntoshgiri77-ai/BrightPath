import { Router } from 'express';
import * as c from '../controllers/publicController.js';
import { validate } from '../middleware/validate.js';
import { publicResultLimiter } from '../middleware/rateLimiter.js';
import { publicLookupSchema } from '../validators/schemas.js';

const r = Router();
r.use(publicResultLimiter); // rate-limited, no auth
r.get('/exams', c.publicExams);
r.post('/lookup', validate(publicLookupSchema), c.publicLookup);
r.post('/result', c.publicResult);
export default r;
