import { Router } from 'express';
import * as c from '../controllers/feeController.js';
import { authenticate, authorize } from '../middleware/auth.js';

const r = Router();
r.use(authenticate);
r.post('/structures', authorize('admin'), c.createFeeStructure);
r.post('/assign', authorize('admin'), c.assignFees);
r.post('/payments', authorize('admin'), c.recordPayment);
r.get('/student/:studentId', c.studentFees);
r.get('/report', authorize('admin'), c.feeReport);
export default r;
