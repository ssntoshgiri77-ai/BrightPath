import { Router } from 'express';
import { login, me, register } from '../controllers/authController.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { authLimiter } from '../middleware/rateLimiter.js';
import { loginSchema, registerSchema } from '../validators/schemas.js';

const r = Router();
r.post('/login', authLimiter, validate(loginSchema), login);
r.get('/me', authenticate, me);
r.post('/register', authenticate, authorize('admin'), validate(registerSchema), register);
export default r;
