import { Router } from 'express';
import * as c from '../controllers/analyticsController.js';
import { authenticate, authorize } from '../middleware/auth.js';

const r = Router();
r.use(authenticate);
r.get('/summary', c.dashboardSummary);
r.get('/performance', c.performanceTrends);
r.get('/attendance', c.attendanceOverview);
r.get('/audit', authorize('admin'), c.auditLogs);
export default r;
