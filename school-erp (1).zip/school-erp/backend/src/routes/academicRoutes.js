import { Router } from 'express';
import * as c from '../controllers/academicController.js';
import { authenticate, authorize } from '../middleware/auth.js';

const r = Router();
r.use(authenticate);
r.get('/classes', c.listClasses);
r.post('/classes', authorize('admin'), c.createClass);
r.post('/sections', authorize('admin'), c.createSection);
r.get('/subjects', c.listSubjects);
r.post('/subjects', authorize('admin'), c.createSubject);
r.post('/assign-teacher', authorize('admin'), c.assignTeacher);
export default r;
