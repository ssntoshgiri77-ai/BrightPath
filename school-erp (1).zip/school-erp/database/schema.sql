-- ============================================================
-- School Management ERP — PostgreSQL Schema (3NF)
-- ============================================================
-- Conventions:
--   * snake_case identifiers
--   * every table has id BIGGENERATED, created_at, updated_at
--   * soft-delete via deleted_at where relevant
--   * multi-school (SaaS) via school_id FK on tenant-scoped tables
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";      -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS "citext";         -- case-insensitive email

-- ---------- ENUM types ----------
DO $$ BEGIN
  CREATE TYPE user_role      AS ENUM ('admin','teacher','student','parent');
  CREATE TYPE attendance_status AS ENUM ('present','absent','late','excused');
  CREATE TYPE exam_status    AS ENUM ('draft','marks_entry','locked','published');
  CREATE TYPE payment_status AS ENUM ('pending','partial','paid','overdue','waived');
  CREATE TYPE channel_type   AS ENUM ('email','whatsapp','sms');
  CREATE TYPE delivery_status AS ENUM ('queued','sent','delivered','failed','retrying');
  CREATE TYPE audience_type  AS ENUM ('all','class','section','student');
EXCEPTION WHEN duplicate_object THEN null; END $$;

-- ============================================================
-- TENANCY
-- ============================================================
CREATE TABLE schools (
  id              BIGSERIAL PRIMARY KEY,
  uuid            UUID NOT NULL DEFAULT gen_random_uuid(),
  name            VARCHAR(200) NOT NULL,
  code            VARCHAR(40)  NOT NULL UNIQUE,
  address         TEXT,
  phone           VARCHAR(30),
  email           CITEXT,
  logo_url        TEXT,
  principal_signature_url TEXT,
  timezone        VARCHAR(60) DEFAULT 'Asia/Dubai',
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================
-- IDENTITY & ACCESS
-- ============================================================
CREATE TABLE users (
  id              BIGSERIAL PRIMARY KEY,
  uuid            UUID NOT NULL DEFAULT gen_random_uuid(),
  school_id       BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  email           CITEXT NOT NULL,
  phone           VARCHAR(30),
  password_hash   TEXT NOT NULL,
  role            user_role NOT NULL,
  full_name       VARCHAR(150) NOT NULL,
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  last_login_at   TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at      TIMESTAMPTZ,
  UNIQUE (school_id, email)
);
CREATE INDEX idx_users_school_role ON users(school_id, role);
CREATE INDEX idx_users_email       ON users(email);

-- ============================================================
-- ACADEMIC STRUCTURE
-- ============================================================
CREATE TABLE academic_years (
  id          BIGSERIAL PRIMARY KEY,
  school_id   BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name        VARCHAR(20) NOT NULL,          -- e.g. 2025-2026
  start_date  DATE NOT NULL,
  end_date    DATE NOT NULL,
  is_current  BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (school_id, name)
);

CREATE TABLE classes (
  id          BIGSERIAL PRIMARY KEY,
  school_id   BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name        VARCHAR(50) NOT NULL,           -- Grade 1, Grade 10 ...
  grade_level SMALLINT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (school_id, name)
);

CREATE TABLE sections (
  id                 BIGSERIAL PRIMARY KEY,
  class_id           BIGINT NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  name               VARCHAR(10) NOT NULL,     -- A, B, C
  class_teacher_id   BIGINT REFERENCES users(id) ON DELETE SET NULL,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (class_id, name)
);

CREATE TABLE subjects (
  id          BIGSERIAL PRIMARY KEY,
  school_id   BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name        VARCHAR(80) NOT NULL,
  code        VARCHAR(20) NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (school_id, code)
);

-- Which subject is taught in which class, by which teacher
CREATE TABLE teacher_assignments (
  id          BIGSERIAL PRIMARY KEY,
  school_id   BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  teacher_id  BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  section_id  BIGINT NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
  subject_id  BIGINT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (section_id, subject_id, teacher_id)
);
CREATE INDEX idx_teacher_assign_teacher ON teacher_assignments(teacher_id);

-- ============================================================
-- PEOPLE
-- ============================================================
CREATE TABLE parents (
  id            BIGSERIAL PRIMARY KEY,
  school_id     BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  user_id       BIGINT REFERENCES users(id) ON DELETE SET NULL,   -- optional login
  full_name     VARCHAR(150) NOT NULL,
  email         CITEXT,
  phone         VARCHAR(30),
  whatsapp      VARCHAR(30),
  relationship  VARCHAR(30) DEFAULT 'guardian',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE students (
  id             BIGSERIAL PRIMARY KEY,
  uuid           UUID NOT NULL DEFAULT gen_random_uuid(),
  school_id      BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  user_id        BIGINT REFERENCES users(id) ON DELETE SET NULL,   -- optional login
  admission_no   VARCHAR(40) NOT NULL,
  first_name     VARCHAR(80) NOT NULL,
  last_name      VARCHAR(80) NOT NULL,
  date_of_birth  DATE NOT NULL,
  gender         VARCHAR(15),
  parent_id      BIGINT REFERENCES parents(id) ON DELETE SET NULL,
  parent_email   CITEXT,
  phone          VARCHAR(30),
  photo_url      TEXT,
  current_section_id BIGINT REFERENCES sections(id) ON DELETE SET NULL,
  admission_date DATE NOT NULL DEFAULT CURRENT_DATE,
  is_active      BOOLEAN NOT NULL DEFAULT TRUE,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at     TIMESTAMPTZ,
  UNIQUE (school_id, admission_no)
);
-- Public-portal lookup: last name + DOB
CREATE INDEX idx_students_public_lookup ON students(school_id, lower(last_name), date_of_birth);
CREATE INDEX idx_students_section       ON students(current_section_id);

CREATE TABLE student_class_history (
  id            BIGSERIAL PRIMARY KEY,
  student_id    BIGINT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  section_id    BIGINT NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
  academic_year_id BIGINT NOT NULL REFERENCES academic_years(id) ON DELETE CASCADE,
  promoted_from_section_id BIGINT REFERENCES sections(id) ON DELETE SET NULL,
  result        VARCHAR(20),                 -- promoted / retained / passed_out
  remarks       TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_sch_student ON student_class_history(student_id);

-- ============================================================
-- ATTENDANCE
-- ============================================================
CREATE TABLE attendance (
  id          BIGSERIAL PRIMARY KEY,
  school_id   BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  student_id  BIGINT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  section_id  BIGINT NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
  att_date    DATE NOT NULL,
  status      attendance_status NOT NULL DEFAULT 'present',
  marked_by   BIGINT REFERENCES users(id) ON DELETE SET NULL,
  remarks     VARCHAR(200),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (student_id, att_date)
);
CREATE INDEX idx_attendance_section_date ON attendance(section_id, att_date);
CREATE INDEX idx_attendance_student      ON attendance(student_id);

-- ============================================================
-- EXAMS & RESULTS
-- ============================================================
CREATE TABLE exams (
  id               BIGSERIAL PRIMARY KEY,
  school_id        BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  academic_year_id BIGINT NOT NULL REFERENCES academic_years(id) ON DELETE CASCADE,
  name             VARCHAR(100) NOT NULL,     -- Term 1, Mid-Term ...
  exam_date_start  DATE,
  exam_date_end    DATE,
  status           exam_status NOT NULL DEFAULT 'draft',
  created_by       BIGINT REFERENCES users(id) ON DELETE SET NULL,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Per-exam-per-subject max/pass configuration
CREATE TABLE exam_subjects (
  id          BIGSERIAL PRIMARY KEY,
  exam_id     BIGINT NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
  subject_id  BIGINT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  section_id  BIGINT NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
  max_marks   NUMERIC(6,2) NOT NULL DEFAULT 100,
  pass_marks  NUMERIC(6,2) NOT NULL DEFAULT 35,
  UNIQUE (exam_id, subject_id, section_id)
);

CREATE TABLE marks (
  id             BIGSERIAL PRIMARY KEY,
  exam_subject_id BIGINT NOT NULL REFERENCES exam_subjects(id) ON DELETE CASCADE,
  student_id     BIGINT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  marks_obtained NUMERIC(6,2) NOT NULL,
  grade          VARCHAR(3),
  is_absent      BOOLEAN NOT NULL DEFAULT FALSE,
  entered_by     BIGINT REFERENCES users(id) ON DELETE SET NULL,
  is_locked      BOOLEAN NOT NULL DEFAULT FALSE,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (exam_subject_id, student_id)
);
CREATE INDEX idx_marks_student ON marks(student_id);

-- Result publish record (locks + published state per section/exam)
CREATE TABLE result_publish (
  id             BIGSERIAL PRIMARY KEY,
  school_id      BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  exam_id        BIGINT NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
  section_id     BIGINT NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
  published_by   BIGINT REFERENCES users(id) ON DELETE SET NULL,
  published_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  notify_sent    BOOLEAN NOT NULL DEFAULT FALSE,
  UNIQUE (exam_id, section_id)
);

CREATE TABLE report_cards (
  id             BIGSERIAL PRIMARY KEY,
  school_id      BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  exam_id        BIGINT NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
  student_id     BIGINT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  total_marks    NUMERIC(8,2),
  max_total      NUMERIC(8,2),
  percentage     NUMERIC(5,2),
  overall_grade  VARCHAR(3),
  rank_in_section SMALLINT,
  remarks        TEXT,
  pdf_url        TEXT,
  generated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (exam_id, student_id)
);
CREATE INDEX idx_reportcards_student ON report_cards(student_id);

-- ============================================================
-- FEES
-- ============================================================
CREATE TABLE fee_structures (
  id          BIGSERIAL PRIMARY KEY,
  school_id   BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  academic_year_id BIGINT NOT NULL REFERENCES academic_years(id) ON DELETE CASCADE,
  name        VARCHAR(100) NOT NULL,          -- Tuition Term 1
  class_id    BIGINT REFERENCES classes(id) ON DELETE CASCADE,
  amount      NUMERIC(10,2) NOT NULL,
  due_date    DATE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE student_fees (
  id            BIGSERIAL PRIMARY KEY,
  school_id     BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  student_id    BIGINT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  fee_structure_id BIGINT NOT NULL REFERENCES fee_structures(id) ON DELETE CASCADE,
  amount_due    NUMERIC(10,2) NOT NULL,
  amount_paid   NUMERIC(10,2) NOT NULL DEFAULT 0,
  status        payment_status NOT NULL DEFAULT 'pending',
  due_date      DATE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (student_id, fee_structure_id)
);
CREATE INDEX idx_student_fees_student ON student_fees(student_id);

CREATE TABLE payments (
  id             BIGSERIAL PRIMARY KEY,
  school_id      BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  student_fee_id BIGINT NOT NULL REFERENCES student_fees(id) ON DELETE CASCADE,
  amount         NUMERIC(10,2) NOT NULL,
  method         VARCHAR(30),                 -- cash, card, bank, online
  reference_no   VARCHAR(80),
  paid_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  recorded_by    BIGINT REFERENCES users(id) ON DELETE SET NULL,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_payments_student_fee ON payments(student_fee_id);

-- ============================================================
-- COMMUNICATION
-- ============================================================
CREATE TABLE announcements (
  id             BIGSERIAL PRIMARY KEY,
  school_id      BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  title          VARCHAR(200) NOT NULL,
  body           TEXT NOT NULL,
  audience       audience_type NOT NULL DEFAULT 'all',
  target_class_id   BIGINT REFERENCES classes(id) ON DELETE SET NULL,
  target_section_id BIGINT REFERENCES sections(id) ON DELETE SET NULL,
  channels       channel_type[] NOT NULL DEFAULT '{email}',
  is_emergency   BOOLEAN NOT NULL DEFAULT FALSE,
  scheduled_at   TIMESTAMPTZ,
  sent_at        TIMESTAMPTZ,
  created_by     BIGINT REFERENCES users(id) ON DELETE SET NULL,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_announcements_school ON announcements(school_id);

CREATE TABLE notification_logs (
  id             BIGSERIAL PRIMARY KEY,
  school_id      BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  announcement_id BIGINT REFERENCES announcements(id) ON DELETE CASCADE,
  student_id     BIGINT REFERENCES students(id) ON DELETE SET NULL,
  recipient      VARCHAR(150) NOT NULL,       -- email/phone
  channel        channel_type NOT NULL,
  status         delivery_status NOT NULL DEFAULT 'queued',
  provider_id    VARCHAR(120),                -- external message id
  error          TEXT,
  attempts       SMALLINT NOT NULL DEFAULT 0,
  sent_at        TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notif_logs_status ON notification_logs(status);
CREATE INDEX idx_notif_logs_ann    ON notification_logs(announcement_id);

-- One-time passwords for the public result portal
CREATE TABLE otp_codes (
  id          BIGSERIAL PRIMARY KEY,
  school_id   BIGINT NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  identifier  VARCHAR(150) NOT NULL,          -- email/phone
  code_hash   TEXT NOT NULL,
  purpose     VARCHAR(40) NOT NULL DEFAULT 'public_result',
  expires_at  TIMESTAMPTZ NOT NULL,
  consumed_at TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_otp_identifier ON otp_codes(identifier, purpose);

-- ============================================================
-- AUDIT
-- ============================================================
CREATE TABLE audit_logs (
  id          BIGSERIAL PRIMARY KEY,
  school_id   BIGINT REFERENCES schools(id) ON DELETE CASCADE,
  actor_id    BIGINT REFERENCES users(id) ON DELETE SET NULL,
  action      VARCHAR(80) NOT NULL,           -- e.g. RESULT_PUBLISH
  entity      VARCHAR(60),                    -- table/domain
  entity_id   BIGINT,
  metadata    JSONB,
  ip_address  INET,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_actor ON audit_logs(actor_id);
CREATE INDEX idx_audit_action ON audit_logs(school_id, action, created_at);

-- ============================================================
-- updated_at trigger
-- ============================================================
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$ LANGUAGE plpgsql;

DO $$
DECLARE t text;
BEGIN
  FOR t IN
    SELECT table_name FROM information_schema.columns
    WHERE column_name='updated_at' AND table_schema='public'
  LOOP
    EXECUTE format(
      'DROP TRIGGER IF EXISTS trg_%1$s_updated ON %1$I;
       CREATE TRIGGER trg_%1$s_updated BEFORE UPDATE ON %1$I
       FOR EACH ROW EXECUTE FUNCTION set_updated_at();', t);
  END LOOP;
END $$;
