-- ============================================================
-- Sample data for School Management ERP
-- Password for ALL seeded users = "Password123!"
-- bcrypt hash below is precomputed (cost 10).
-- ============================================================
BEGIN;

-- School
INSERT INTO schools (name, code, address, phone, email, timezone)
VALUES ('Greenwood International School','GWIS','123 Knowledge Ave, Dubai','+971-4-000-0000','info@greenwood.edu','Asia/Dubai');

-- Academic year
INSERT INTO academic_years (school_id, name, start_date, end_date, is_current)
VALUES (1,'2025-2026','2025-08-01','2026-06-30', TRUE);

-- Users (bcrypt of "Password123!")
-- $2b$10$TiEu2C25nawO6Em4ytHsxuhCRHgw7MM1q.Th49nD9/eHubETgSdFO
INSERT INTO users (school_id,email,phone,password_hash,role,full_name) VALUES
 (1,'admin@greenwood.edu','+971500000001','$2b$10$TiEu2C25nawO6Em4ytHsxuhCRHgw7MM1q.Th49nD9/eHubETgSdFO','admin','System Admin'),
 (1,'teacher1@greenwood.edu','+971500000002','$2b$10$TiEu2C25nawO6Em4ytHsxuhCRHgw7MM1q.Th49nD9/eHubETgSdFO','teacher','Sarah Johnson'),
 (1,'teacher2@greenwood.edu','+971500000003','$2b$10$TiEu2C25nawO6Em4ytHsxuhCRHgw7MM1q.Th49nD9/eHubETgSdFO','teacher','David Lee'),
 (1,'student1@greenwood.edu','+971500000004','$2b$10$TiEu2C25nawO6Em4ytHsxuhCRHgw7MM1q.Th49nD9/eHubETgSdFO','student','Aisha Khan'),
 (1,'parent1@greenwood.edu','+971500000005','$2b$10$TiEu2C25nawO6Em4ytHsxuhCRHgw7MM1q.Th49nD9/eHubETgSdFO','parent','Imran Khan');

-- Classes & sections
INSERT INTO classes (school_id,name,grade_level) VALUES
 (1,'Grade 9',9),(1,'Grade 10',10);
INSERT INTO sections (class_id,name,class_teacher_id) VALUES
 (1,'A',2),(1,'B',3),(2,'A',2);

-- Subjects
INSERT INTO subjects (school_id,name,code) VALUES
 (1,'Mathematics','MATH'),(1,'English','ENG'),(1,'Science','SCI'),
 (1,'Social Studies','SOC'),(1,'Computer Science','CS');

-- Teacher assignments (teacher user_id 2 & 3 to section 1)
INSERT INTO teacher_assignments (school_id,teacher_id,section_id,subject_id) VALUES
 (1,2,1,1),(1,2,1,3),(1,3,1,2),(1,3,1,4),(1,2,1,5);

-- Parent
INSERT INTO parents (school_id,user_id,full_name,email,phone,whatsapp) VALUES
 (1,5,'Imran Khan','parent1@greenwood.edu','+971500000005','+971500000005');

-- Students (section 1 = Grade 9 A)
INSERT INTO students (school_id,user_id,admission_no,first_name,last_name,date_of_birth,gender,parent_id,parent_email,phone,current_section_id,admission_date) VALUES
 (1,4,'GWIS-0001','Aisha','Khan','2010-03-15','female',1,'parent1@greenwood.edu','+971500000005',1,'2024-08-01'),
 (1,NULL,'GWIS-0002','Omar','Saeed','2010-05-20','male',NULL,'parent.omar@example.com','+971500000010',1,'2024-08-01'),
 (1,NULL,'GWIS-0003','Lina','Farah','2010-01-11','female',NULL,'parent.lina@example.com','+971500000011',1,'2024-08-01');

-- Class history
INSERT INTO student_class_history (student_id,section_id,academic_year_id,result) VALUES
 (1,1,1,'promoted'),(2,1,1,'promoted'),(3,1,1,'promoted');

-- Attendance (a few days)
INSERT INTO attendance (school_id,student_id,section_id,att_date,status,marked_by) VALUES
 (1,1,1,'2026-07-20','present',2),(1,2,1,'2026-07-20','present',2),(1,3,1,'2026-07-20','absent',2),
 (1,1,1,'2026-07-21','present',2),(1,2,1,'2026-07-21','late',2),(1,3,1,'2026-07-21','present',2);

-- Exam
INSERT INTO exams (school_id,academic_year_id,name,exam_date_start,exam_date_end,status,created_by) VALUES
 (1,1,'Term 1 Examination','2026-06-01','2026-06-10','marks_entry',1);

-- Exam subjects for section 1
INSERT INTO exam_subjects (exam_id,subject_id,section_id,max_marks,pass_marks) VALUES
 (1,1,1,100,35),(1,2,1,100,35),(1,3,1,100,35),(1,4,1,100,35),(1,5,1,100,35);

-- Marks for Aisha (student 1)
INSERT INTO marks (exam_subject_id,student_id,marks_obtained,grade,entered_by) VALUES
 (1,1,88,'A',2),(2,1,76,'B',3),(3,1,92,'A+',2),(4,1,81,'A',3),(5,1,95,'A+',2),
 (1,2,72,'B',2),(2,2,68,'C',3),(3,2,80,'A',2),(4,2,74,'B',3),(5,2,85,'A',2);

-- Fees
INSERT INTO fee_structures (school_id,academic_year_id,name,class_id,amount,due_date) VALUES
 (1,1,'Tuition Term 1',1,5000,'2026-08-15');
INSERT INTO student_fees (school_id,student_id,fee_structure_id,amount_due,amount_paid,status,due_date) VALUES
 (1,1,1,5000,3000,'partial','2026-08-15'),
 (1,2,1,5000,5000,'paid','2026-08-15'),
 (1,3,1,5000,0,'pending','2026-08-15');
INSERT INTO payments (school_id,student_fee_id,amount,method,reference_no,recorded_by) VALUES
 (1,1,3000,'bank','TXN-1001',1),(1,2,5000,'online','TXN-1002',1);

COMMIT;
