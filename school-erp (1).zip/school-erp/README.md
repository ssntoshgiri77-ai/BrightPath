# 🎓 School Management ERP — Enterprise Edition

A full-stack, multi-tenant School ERP covering academics, attendance, exams, result publishing with branded PDF report cards, fees, multi-channel notifications (email / WhatsApp / SMS), a public no-login result portal, analytics, and audit logging.

> **Status:** The database schema, backend API, PDF report-card generator, and public portal have been **validated end-to-end** (login → marks → publish → PDF → lock → public OTP result). See _Validation_ below.

---

## 🏗️ Architecture

```
school-erp/
├── database/            # PostgreSQL (3NF) schema + sample seed
│   ├── schema.sql       # 23 tables, ENUMs, FKs, indexes, updated_at triggers
│   └── seed.sql         # demo school, users, students, marks, fees
├── backend/             # Node.js + Express (ESM) REST API
│   └── src/
│       ├── config/      # env + pg pool (+ transaction helper)
│       ├── middleware/  # JWT auth, RBAC, rate limiting, validation, errors
│       ├── utils/       # jwt, bcrypt, grades, audit, asyncHandler
│       ├── services/    # email (SMTP), whatsapp/sms (Twilio), notifications,
│       │                #   otp, pdf report-card generator (pdfkit)
│       ├── controllers/ # auth, student, academic, attendance, exam,
│       │                #   result, fee, announcement, public, analytics
│       ├── routes/      # one router per domain + aggregator
│       ├── validators/  # zod schemas
│       └── scripts/     # migrate.js, seed.js
├── frontend/            # React + Vite + Tailwind + Recharts
│   └── src/
│       ├── context/     # AuthContext (JWT in localStorage)
│       ├── api/         # axios client w/ token + 401 interceptor
│       ├── components/  # ProtectedRoute, StatCard, DataTable
│       ├── layouts/     # role-based DashboardLayout
│       └── pages/       # Login, Dashboard, Students, Attendance, Exams,
│                        #   Results, Fees, Announcements, Analytics,
│                        #   AuditLog, PublicResult
├── docker-compose.yml   # db + backend + frontend (nginx)
└── README.md
```

**Tech stack:** Node.js/Express · PostgreSQL · React · Tailwind CSS · JWT (RBAC) · bcrypt · pdfkit · Nodemailer · Twilio · Recharts · Docker.

---

## 🚀 Quick start

### Option A — Docker (recommended)
```bash
cp .env.example .env          # edit JWT_SECRET etc.
docker compose up --build
# Frontend  → http://localhost:5173
# Backend   → http://localhost:4000
# Postgres  → localhost:5432 (schema + seed auto-applied)
```

### Option B — Local dev
```bash
# 1. Database
createdb school_erp
psql school_erp -f database/schema.sql
psql school_erp -f database/seed.sql

# 2. Backend
cd backend
cp .env.example .env          # set DATABASE_URL, JWT_SECRET, SMTP, TWILIO
npm install
npm run dev                   # http://localhost:4000

# 3. Frontend
cd ../frontend
npm install
npm run dev                   # http://localhost:5173 (proxies /api → :4000)
```

### Demo credentials (password for all: `Password123!`)
| Role    | Email                      |
|---------|----------------------------|
| Admin   | admin@greenwood.edu        |
| Teacher | teacher1@greenwood.edu     |
| Student | student1@greenwood.edu     |
| Parent  | parent1@greenwood.edu      |

Public portal → `http://localhost:5173/public` (School code `GWIS`, Last name `Khan`, DOB `2010-03-15`).

---

## 👥 Roles & permissions (RBAC)

| Capability                    | Admin | Teacher | Student | Parent |
|-------------------------------|:---:|:---:|:---:|:---:|
| Manage users/classes/subjects | ✅ |    |    |    |
| Admit / promote students      | ✅ |    |    |    |
| Mark attendance               | ✅ | ✅ |    |    |
| Enter marks                   | ✅ | ✅ |    |    |
| Publish results (lock+notify) | ✅ |    |    |    |
| View results / report cards   | ✅ | ✅ | ✅ | ✅ |
| Fees & payments               | ✅ |    |    | view |
| Announcements                 | ✅ |    |    |    |
| Analytics & audit log         | ✅ |    |    |    |

Enforced via `authenticate` (JWT) + `authorize(...roles)` middleware.

---

## 🔑 Core flows

### Result publishing (the automation centerpiece)
`POST /api/exams/:examId/publish { sectionId }` runs atomically:
1. **Locks** every mark for that exam+section (`marks.is_locked = true`).
2. **Computes** each student's total, %, grade, and **rank in section**; upserts `report_cards`.
3. Records `result_publish` and sets `exams.status = 'published'`.
4. **Generates a branded PDF** per student (logo, details, marks table, totals, remarks, signature lines).
5. **Emails parents** with the PDF attached (best-effort, logged).

After publishing, further mark edits return **423 Locked**.

### Public result portal (no login)
1. `POST /api/public/lookup { schoolCode, lastName, dateOfBirth, requireOtp }` — rate-limited; returns masked contact and (optionally) sends an OTP.
2. `POST /api/public/result { schoolId, studentId, examId, otp }` — verifies OTP against the on-file contact **server-side**, returns the result + PDF link. Only **published** results are exposed.

### Notifications
`POST /api/announcements` targets `all` / `class` / `section`, fans out across `email`/`whatsapp`/`sms`, writes a `notification_logs` row per recipient with delivery status, supports emergency flag & scheduling. `POST /api/announcements/retry` reprocesses failed messages (max 3 attempts).

---

## 📡 API reference (selected)

| Method | Endpoint | Auth | Purpose |
|---|---|---|---|
| POST | `/api/auth/login` | – | Login → JWT |
| POST | `/api/auth/register` | admin | Create user |
| GET/POST | `/api/students` | admin/teacher | List / admit |
| POST | `/api/students/promote` | admin | Promote + history |
| GET/POST | `/api/attendance` | admin/teacher | Read / bulk mark |
| GET | `/api/attendance/stats/:studentId` | any | Attendance % |
| POST | `/api/exams` · `/:id/subjects` · `/marks` | admin/teacher | Exam setup + marks |
| POST | `/api/exams/:examId/publish` | admin | Publish + PDF + notify |
| GET | `/api/exams/:examId/report-card/:studentId` | any | Report card |
| POST | `/api/fees/structures` · `/assign` · `/payments` | admin | Fee lifecycle |
| GET | `/api/fees/report` | admin | Collection summary |
| POST | `/api/announcements` · `/retry` | admin | Multi-channel comms |
| POST | `/api/public/lookup` · `/result` | – (rate-limited) | Public portal |
| GET | `/api/analytics/summary` · `/performance` · `/attendance` · `/audit` | admin | Dashboards |

---

## 🗄️ Database (3NF)

23 tables: `schools, users, academic_years, classes, sections, subjects, teacher_assignments, parents, students, student_class_history, attendance, exams, exam_subjects, marks, result_publish, report_cards, fee_structures, student_fees, payments, announcements, notification_logs, otp_codes, audit_logs`.

Highlights: multi-tenant via `school_id`; ENUM types for statuses; foreign keys with sensible `ON DELETE`; targeted indexes (incl. public-lookup index on `lower(last_name)+date_of_birth`); automatic `updated_at` triggers.

---

## 🔐 Security
- JWT auth + role-based authorization on every protected route
- bcrypt password hashing (cost 10)
- zod input validation
- Rate limiting (global, auth, and strict public-result limiter)
- OTP verification for the public portal (identifier derived server-side, never trusted from client)
- Helmet, CORS allow-list, payload size limits
- Full audit trail of admin actions

---

## ✅ Validation performed
Run against a live PostgreSQL 17 instance with the seed data:
- ✅ Schema + seed apply cleanly (23 tables)
- ✅ Admin login returns JWT; RBAC enforced
- ✅ Marks aggregation → report cards (86.4% → A, rank 1)
- ✅ `publish` locks marks (subsequent edit → 423), generates 2 PDFs
- ✅ Branded PDF report card renders correctly
- ✅ Public lookup (last name + DOB) → OTP → result; wrong OTP rejected

---

## 🚀 Bonus / roadmap
Multi-school SaaS is already modeled (`school_id` everywhere). Suggested next steps: background job queue (BullMQ) for notifications/PDFs at scale, S3 storage adapter for uploads, AI performance prediction on `report_cards` history, and mobile-ready endpoints (the API is already JSON/stateless).

---

_Built as an enterprise-grade reference implementation. Configure SMTP/Twilio env vars to enable live email/WhatsApp delivery; without them the system degrades gracefully and still logs delivery attempts._
