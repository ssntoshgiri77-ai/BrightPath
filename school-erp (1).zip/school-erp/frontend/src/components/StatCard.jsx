export default function StatCard({ label, value, accent = 'brand' }) {
  const map = { brand: 'text-brand-600', green: 'text-emerald-600', red: 'text-rose-600', amber: 'text-amber-600' };
  return (
    <div className="card">
      <p className="text-xs uppercase tracking-wide text-slate-500">{label}</p>
      <p className={`mt-2 text-2xl font-bold ${map[accent] || map.brand}`}>{value}</p>
    </div>
  );
}
