export default function DataTable({ columns, rows, empty = 'No records' }) {
  return (
    <div className="table-wrapper overflow-x-auto card p-0">
      <table className="min-w-full text-sm">
        <thead className="bg-slate-100 text-slate-600">
          <tr>{columns.map(c => <th key={c.key} className="text-left font-semibold px-4 py-3">{c.label}</th>)}</tr>
        </thead>
        <tbody>
          {rows.length === 0 && (
            <tr><td colSpan={columns.length} className="px-4 py-8 text-center text-slate-400">{empty}</td></tr>
          )}
          {rows.map((row, i) => (
            <tr key={row.id || i} className="border-t border-slate-100 hover:bg-slate-50">
              {columns.map(c => <td key={c.key} className="px-4 py-3">{c.render ? c.render(row) : row[c.key]}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
