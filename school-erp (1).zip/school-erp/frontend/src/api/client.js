import axios from 'axios';

// In production (Render static site) set VITE_API_URL to the backend URL, e.g.
//   https://school-erp-backend.onrender.com/api
// In local dev it falls back to '/api' which Vite proxies to localhost:4000.
const baseURL = import.meta.env.VITE_API_URL || '/api';

const api = axios.create({ baseURL });

api.interceptors.request.use((cfg) => {
  const token = localStorage.getItem('accessToken');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401 && !err.config.url.includes('/auth/login')) {
      localStorage.removeItem('accessToken');
      localStorage.removeItem('user');
      if (!location.pathname.startsWith('/public') && location.pathname !== '/login') {
        location.href = '/login';
      }
    }
    return Promise.reject(err);
  }
);

export default api;
