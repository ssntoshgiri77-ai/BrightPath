import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

const NAV = [
  { to: '/app', label: 'Dashboard', roles: ['admin','teacher','student','parent'], end: true },
  { to: '/app/students', label: 'Students', roles: ['admin','teacher'] },
  { to: '/app/attendance', label: 'Attendance', roles: ['admin','teacher'] },
  { to: '/app/exams', label: 'Exams & Marks', roles: ['admin','teacher'] },
  { to: '/app/results', label: 'Results', roles: ['admin','teacher','student','parent'] },
  { to: '/app/fees', label: 'Fees', roles: ['admin','parent'] },
  { to: '/app/announcements', label: 'Announcements', roles: ['admin'] },
  { to: '/app/analytics', label: 'Analytics', roles: ['admin'] },
  { to: '/app/audit', label: 'Audit Log', roles: ['admin'] },
];

export default function DashboardLayout() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const items = NAV.filter(n => n.roles.includes(user?.role));

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <aside className="w-full md:w-64 bg-brand-900 text-white md:min-h-screen">
        <div className="p-5 border-b border-white/10">
          <h1 className="text-lg font-bold">🎓 School ERP</h1>
          <p className="text-xs text-white/60 mt-1">{user?.fullName} · {user?.role}</p>
        </div>
        <nav className="p-3 flex md:flex-col gap-1 flex-wrap">
          {items.map(n => (
            <NavLink key={n.to} to={n.to} end={n.end}
              className={({isActive}) => `px-3 py-2 rounded-lg text-sm ${isActive ? 'bg-white/15 font-medium' : 'text-white/80 hover:bg-white/10'}`}>
              {n.label}
            </NavLink>
          ))}
        </nav>
        <div className="p-3 mt-auto">
          <button onClick={() => { logout(); nav('/login'); }} className="w-full btn bg-white/10 text-white hover:bg-white/20">Logout</button>
        </div>
      </aside>
      <main className="flex-1 p-4 md:p-8 max-w-7xl mx-auto w-full">
        <Outlet />
      </main>
    </div>
  );
}
