import { Routes, Route, Navigate } from 'react-router-dom';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import DashboardLayout from './layouts/DashboardLayout.jsx';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Students from './pages/Students.jsx';
import Attendance from './pages/Attendance.jsx';
import Exams from './pages/Exams.jsx';
import Results from './pages/Results.jsx';
import Fees from './pages/Fees.jsx';
import Announcements from './pages/Announcements.jsx';
import Analytics from './pages/Analytics.jsx';
import AuditLog from './pages/AuditLog.jsx';
import PublicResult from './pages/PublicResult.jsx';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/app" replace />} />
      <Route path="/login" element={<Login />} />
      <Route path="/public" element={<PublicResult />} />

      <Route path="/app" element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}>
        <Route index element={<Dashboard />} />
        <Route path="students" element={<ProtectedRoute roles={['admin','teacher']}><Students /></ProtectedRoute>} />
        <Route path="attendance" element={<ProtectedRoute roles={['admin','teacher']}><Attendance /></ProtectedRoute>} />
        <Route path="exams" element={<ProtectedRoute roles={['admin','teacher']}><Exams /></ProtectedRoute>} />
        <Route path="results" element={<Results />} />
        <Route path="fees" element={<Fees />} />
        <Route path="announcements" element={<ProtectedRoute roles={['admin']}><Announcements /></ProtectedRoute>} />
        <Route path="analytics" element={<ProtectedRoute roles={['admin']}><Analytics /></ProtectedRoute>} />
        <Route path="audit" element={<ProtectedRoute roles={['admin']}><AuditLog /></ProtectedRoute>} />
      </Route>

      <Route path="*" element={<Navigate to="/app" replace />} />
    </Routes>
  );
}
