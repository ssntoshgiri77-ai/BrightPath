import { useEffect, useState } from 'react';
import api from '../api/client.js';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid } from 'recharts';

export default function Analytics() {
  const [perf, setPerf] = useState([]);
  const [att, setAtt] = useState([]);
  useEffect(() => {
    api.get('/analytics/performance').then(r=>setPerf(r.data.map(x=>({...x, avg:Number(x.avg_percentage)}))));
    api.get('/analytics/attendance').then(r=>setAtt(r.data.map(x=>({ name:`${x.class_name}-${x.section_name}`, pct:Number(x.attendance_pct) }))));
  }, []);

  return (
    <div>
      <h2 className="text-2xl font-bold mb-5">Analytics</h2>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="card">
          <h3 className="font-semibold mb-3">Performance Trend (avg %)</h3>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={perf}>
              <CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="exam" /><YAxis domain={[0,100]} /><Tooltip />
              <Line type="monotone" dataKey="avg" stroke="#2563eb" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="card">
          <h3 className="font-semibold mb-3">Attendance by Section (%)</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={att}>
              <CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="name" /><YAxis domain={[0,100]} /><Tooltip />
              <Bar dataKey="pct" fill="#2563eb" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
