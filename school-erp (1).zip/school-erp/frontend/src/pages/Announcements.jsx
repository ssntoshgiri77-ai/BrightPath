import { useEffect, useState } from 'react';
import api from '../api/client.js';
import DataTable from '../components/DataTable.jsx';

export default function Announcements() {
  const [rows, setRows] = useState([]);
  const [classes, setClasses] = useState([]);
  const [form, setForm] = useState({ title:'', body:'', audience:'all', targetClassId:'', channels:['email'], isEmergency:false });

  const load = () => api.get('/announcements').then(r=>setRows(r.data));
  useEffect(() => { load(); api.get('/academic/classes').then(r=>setClasses(r.data)); }, []);

  const toggleChannel = (ch) => setForm(f => ({...f, channels: f.channels.includes(ch) ? f.channels.filter(c=>c!==ch) : [...f.channels, ch]}));

  const send = async (e) => {
    e.preventDefault();
    const payload = { ...form, targetClassId: form.audience==='class' ? Number(form.targetClassId) : null };
    const { data } = await api.post('/announcements', payload);
    alert(`Sent: ${data.sent||0} / Queued: ${data.queued||0} / Failed: ${data.failed||0}`);
    setForm({ title:'', body:'', audience:'all', targetClassId:'', channels:['email'], isEmergency:false });
    load();
  };

  const retry = async () => { const { data } = await api.post('/announcements/retry'); alert(`Retried ${data.retried}, succeeded ${data.succeeded}`); load(); };

  const columns = [
    { key:'title', label:'Title', render:r=><span>{r.is_emergency&&'🚨 '}{r.title}</span> },
    { key:'audience', label:'Audience' },
    { key:'channels', label:'Channels', render:r=>(r.channels||[]).join(', ') },
    { key:'delivery', label:'Delivery', render:r=>`${r.sent}/${r.total} sent${r.failed>0?`, ${r.failed} failed`:''}` },
    { key:'created_at', label:'Date', render:r=>(r.created_at||'').slice(0,10) },
  ];

  return (
    <div>
      <div className="flex justify-between items-center mb-5">
        <h2 className="text-2xl font-bold">Announcements</h2>
        <button className="btn-ghost" onClick={retry}>Retry Failed</button>
      </div>
      <form onSubmit={send} className="card mb-5 space-y-3">
        <div><label className="label">Title</label><input className="input" required value={form.title} onChange={e=>setForm({...form,title:e.target.value})} /></div>
        <div><label className="label">Message</label><textarea className="input" rows="3" required value={form.body} onChange={e=>setForm({...form,body:e.target.value})} /></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div><label className="label">Audience</label>
            <select className="input" value={form.audience} onChange={e=>setForm({...form,audience:e.target.value})}>
              <option value="all">All Students</option><option value="class">Specific Class</option>
            </select></div>
          {form.audience==='class' && (
            <div><label className="label">Class</label>
              <select className="input" value={form.targetClassId} onChange={e=>setForm({...form,targetClassId:e.target.value})}>
                <option value="">Select</option>{classes.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}
              </select></div>
          )}
        </div>
        <div className="flex flex-wrap gap-4 items-center">
          <span className="label mb-0">Channels:</span>
          {['email','whatsapp','sms'].map(ch=>(
            <label key={ch} className="flex items-center gap-1 text-sm capitalize">
              <input type="checkbox" checked={form.channels.includes(ch)} onChange={()=>toggleChannel(ch)} /> {ch}
            </label>))}
          <label className="flex items-center gap-1 text-sm ml-auto">
            <input type="checkbox" checked={form.isEmergency} onChange={e=>setForm({...form,isEmergency:e.target.checked})} /> 🚨 Emergency
          </label>
        </div>
        <button className="btn-primary">Send Announcement</button>
      </form>
      <DataTable columns={columns} rows={rows} empty="No announcements" />
    </div>
  );
}
