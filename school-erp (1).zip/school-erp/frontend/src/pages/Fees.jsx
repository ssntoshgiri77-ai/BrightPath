import { useEffect, useState } from 'react';
import api from '../api/client.js';
import DataTable from '../components/DataTable.jsx';
import StatCard from '../components/StatCard.jsx';
import { useAuth } from '../context/AuthContext.jsx';

export default function Fees() {
  const { user } = useAuth();
  const [report, setReport] = useState(null);
  const [studentId, setStudentId] = useState('');
  const [fees, setFees] = useState([]);

  useEffect(() => { if (user.role==='admin') api.get('/fees/report').then(r=>setReport(r.data)); }, [user.role]);
  const loadStudent = () => studentId && api.get(`/fees/student/${studentId}`).then(r=>setFees(r.data));

  const columns = [
    { key:'fee_name', label:'Fee' },
    { key:'amount_due', label:'Due', render:r=>`$${r.amount_due}` },
    { key:'amount_paid', label:'Paid', render:r=>`$${r.amount_paid}` },
    { key:'balance', label:'Balance', render:r=>`$${r.balance}` },
    { key:'status', label:'Status', render:r=><span className={`badge ${r.status==='paid'?'bg-emerald-100 text-emerald-700':r.status==='partial'?'bg-amber-100 text-amber-700':'bg-rose-100 text-rose-700'}`}>{r.status}</span> },
  ];

  return (
    <div>
      <h2 className="text-2xl font-bold mb-5">Fee Management</h2>
      {report && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
          <StatCard label="Total Due" value={`$${report.total_due}`} />
          <StatCard label="Collected" value={`$${report.total_collected}`} accent="green" />
          <StatCard label="Outstanding" value={`$${report.total_outstanding}`} accent="red" />
          <StatCard label="Paid / Pending" value={`${report.paid_count}/${report.pending_count}`} accent="amber" />
        </div>
      )}
      <div className="card mb-4 flex gap-2 items-end">
        <div><label className="label">Student ID</label><input className="input w-40" value={studentId} onChange={e=>setStudentId(e.target.value)} /></div>
        <button className="btn-ghost" onClick={loadStudent}>View Fees</button>
      </div>
      <DataTable columns={columns} rows={fees} empty="Enter a student ID to view fees" />
    </div>
  );
}
