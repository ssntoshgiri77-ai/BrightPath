import { useEffect, useState } from 'react';
import api from '../api/client.js';

export default function Attendance() {
  const [classes, setClasses] = useState([]);
  const [sectionId, setSectionId] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0,10));
  const [rows, setRows] = useState([]);

  useEffect(() => { api.get('/academic/classes').then(r => setClasses(r.data)); }, []);
  const load = () => { if (sectionId) api.get('/attendance', { params:{ sectionId, date }}).then(r=>setRows(r.data.map(x=>({...x, status:x.status||'present'})))); };
  useEffect(() => { load(); }, [sectionId, date]);

  const save = async () => {
    await api.post('/attendance', { sectionId:Number(sectionId), date, records: rows.map(r=>({ studentId:r.student_id, status:r.status })) });
    alert('Attendance saved');
  };

  const sections = classes.flatMap(c => (c.sections||[]).map(s => ({ id:s.id, label:`${c.name}-${s.name}` })));

  return (
    <div>
      <h2 className="text-2xl font-bold mb-5">Attendance</h2>
      <div className="card mb-4 flex flex-wrap gap-3 items-end">
        <div><label className="label">Section</label>
          <select className="input w-48" value={sectionId} onChange={e=>setSectionId(e.target.value)}>
            <option value="">Select section</option>
            {sections.map(s=><option key={s.id} value={s.id}>{s.label}</option>)}
          </select></div>
        <div><label className="label">Date</label><input className="input" type="date" value={date} onChange={e=>setDate(e.target.value)} /></div>
        {rows.length>0 && <button className="btn-primary" onClick={save}>Save Attendance</button>}
      </div>
      {rows.length>0 && (
        <div className="card p-0 overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-slate-100"><tr><th className="text-left px-4 py-3">Student</th><th className="text-left px-4 py-3">Status</th></tr></thead>
            <tbody>
              {rows.map((r,i)=>(
                <tr key={r.student_id} className="border-t border-slate-100">
                  <td className="px-4 py-2">{r.first_name} {r.last_name}</td>
                  <td className="px-4 py-2">
                    <select className="input w-40" value={r.status} onChange={e=>{const c=[...rows];c[i].status=e.target.value;setRows(c);}}>
                      {['present','absent','late','excused'].map(s=><option key={s} value={s}>{s}</option>)}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
