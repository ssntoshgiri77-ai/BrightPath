import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Login() {
  const { login } = useAuth();
  const nav = useNavigate();
  const [email, setEmail] = useState('admin@greenwood.edu');
  const [password, setPassword] = useState('Password123!');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError('');
    try { await login(email, password); nav('/app'); }
    catch (err) { setError(err.response?.data?.error || 'Login failed'); }
    finally { setBusy(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-brand-900 to-brand-700">
      <div className="card w-full max-w-md">
        <h1 className="text-2xl font-bold text-brand-900">🎓 School ERP</h1>
        <p className="text-sm text-slate-500 mb-6">Sign in to your account</p>
        {error && <div className="mb-4 rounded-lg bg-rose-50 text-rose-700 px-3 py-2 text-sm">{error}</div>}
        <form onSubmit={submit} className="space-y-4">
          <div><label className="label">Email</label>
            <input className="input" value={email} onChange={e=>setEmail(e.target.value)} type="email" required /></div>
          <div><label className="label">Password</label>
            <input className="input" value={password} onChange={e=>setPassword(e.target.value)} type="password" required /></div>
          <button className="btn-primary w-full" disabled={busy}>{busy ? 'Signing in...' : 'Sign in'}</button>
        </form>
        <div className="mt-4 text-center text-sm">
          <Link to="/public" className="text-brand-600 hover:underline">Public result portal →</Link>
        </div>
        <p className="mt-4 text-xs text-slate-400">Demo: admin@greenwood.edu / Password123!</p>
      </div>
    </div>
  );
}
