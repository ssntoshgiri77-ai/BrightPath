import { useEffect, useState } from 'react';
import api from '../api/client.js';
import DataTable from '../components/DataTable.jsx';

export default function Students() {
  const [rows, setRows] = useState([]);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ admissionNo:'', firstName:'', lastName:'', dateOfBirth:'', parentEmail:'' });
  const [show, setShow] = useState(false);

  const load = () => api.get('/students', { params: { search } }).then(r => setRows(r.data));
  useEffect(() => { load(); }, []);

  const create = async (e) => {
    e.preventDefault();
    await api.post('/students', form);
    setShow(false); setForm({ admissionNo:'', firstName:'', lastName:'', dateOfBirth:'', parentEmail:'' });
    load();
  };

  const columns = [
    { key:'admission_no', label:'Admission #' },
    { key:'name', label:'Name', render:r => `${r.first_name} ${r.last_name}` },
    { key:'class', label:'Class', render:r => r.class_name ? `${r.class_name}-${r.section_name}` : '-' },
    { key:'date_of_birth', label:'DOB', render:r => (r.date_of_birth||'').slice(0,10) },
    { key:'parent_email', label:'Parent Email' },
  ];

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
        <h2 className="text-2xl font-bold">Students</h2>
        <div className="flex gap-2">
          <input className="input w-48" placeholder="Search..." value={search}
            onChange={e=>setSearch(e.target.value)} onKeyDown={e=>e.key==='Enter'&&load()} />
          <button className="btn-ghost" onClick={load}>Search</button>
          <button className="btn-primary" onClick={()=>setShow(!show)}>+ Admit Student</button>
        </div>
      </div>
      {show && (
        <form onSubmit={create} className="card mb-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          <div><label className="label">Admission No</label><input className="input" required value={form.admissionNo} onChange={e=>setForm({...form,admissionNo:e.target.value})}/></div>
          <div><label className="label">First Name</label><input className="input" required value={form.firstName} onChange={e=>setForm({...form,firstName:e.target.value})}/></div>
          <div><label className="label">Last Name</label><input className="input" required value={form.lastName} onChange={e=>setForm({...form,lastName:e.target.value})}/></div>
          <div><label className="label">Date of Birth</label><input className="input" type="date" required value={form.dateOfBirth} onChange={e=>setForm({...form,dateOfBirth:e.target.value})}/></div>
          <div><label className="label">Parent Email</label><input className="input" type="email" value={form.parentEmail} onChange={e=>setForm({...form,parentEmail:e.target.value})}/></div>
          <div className="flex items-end"><button className="btn-primary w-full">Save</button></div>
        </form>
      )}
      <DataTable columns={columns} rows={rows} empty="No students yet" />
    </div>
  );
}
