import { useEffect, useState } from 'react';
import api from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function Results() {
  const { user } = useAuth();
  const [exams, setExams] = useState([]);
  const [examId, setExamId] = useState('');
  const [studentId, setStudentId] = useState('');
  const [report, setReport] = useState(null);
  const [err, setErr] = useState('');

  useEffect(() => { api.get('/exams').then(r => setExams(r.data.filter(e=>e.status==='published'))); }, []);

  const fetchReport = async () => {
    setErr(''); setReport(null);
    try { const { data } = await api.get(`/exams/${examId}/report-card/${studentId}`); setReport(data); }
    catch (e) { setErr(e.response?.data?.error || 'Not available'); }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-5">Results & Report Cards</h2>
      <div className="card mb-4 flex flex-wrap gap-3 items-end">
        <div><label className="label">Exam</label>
          <select className="input w-56" value={examId} onChange={e=>setExamId(e.target.value)}>
            <option value="">Select exam</option>
            {exams.map(e=><option key={e.id} value={e.id}>{e.name}</option>)}
          </select></div>
        <div><label className="label">Student ID</label><input className="input w-32" value={studentId} onChange={e=>setStudentId(e.target.value)} /></div>
        <button className="btn-primary" onClick={fetchReport} disabled={!examId||!studentId}>View</button>
      </div>
      {err && <div className="card text-rose-600">{err}</div>}
      {report && (
        <div className="card">
          <div className="flex justify-between items-start flex-wrap gap-2">
            <div>
              <h3 className="text-lg font-bold">{report.exam_name}</h3>
              <p className="text-slate-500 text-sm">Report Card</p>
            </div>
            {report.pdf_url && <a className="btn-primary" href={report.pdf_url} target="_blank" rel="noreferrer">Download PDF</a>}
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4">
            <div><p className="text-xs text-slate-500">Total</p><p className="font-bold">{report.total_marks}/{report.max_total}</p></div>
            <div><p className="text-xs text-slate-500">Percentage</p><p className="font-bold">{report.percentage}%</p></div>
            <div><p className="text-xs text-slate-500">Grade</p><p className="font-bold">{report.overall_grade}</p></div>
            <div><p className="text-xs text-slate-500">Rank</p><p className="font-bold">{report.rank_in_section}</p></div>
          </div>
          {report.remarks && <p className="mt-4 text-sm text-slate-600"><b>Remarks:</b> {report.remarks}</p>}
        </div>
      )}
    </div>
  );
}
