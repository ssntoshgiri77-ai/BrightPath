import { useEffect, useState } from 'react';
import api from '../api/client.js';
import StatCard from '../components/StatCard.jsx';
import { useAuth } from '../context/AuthContext.jsx';

export default function Dashboard() {
  const { user } = useAuth();
  const [s, setS] = useState(null);
  useEffect(() => {
    if (['admin','teacher'].includes(user.role))
      api.get('/analytics/summary').then(r => setS(r.data)).catch(()=>{});
  }, [user.role]);

  return (
    <div>
      <h2 className="text-2xl font-bold mb-1">Welcome, {user.fullName}</h2>
      <p className="text-slate-500 mb-6 capitalize">{user.role} dashboard</p>
      {s ? (
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          <StatCard label="Students" value={s.students} />
          <StatCard label="Teachers" value={s.teachers} />
          <StatCard label="Classes" value={s.classes} />
          <StatCard label="Fees Collected" value={`$${s.feesCollected}`} accent="green" />
          <StatCard label="Outstanding" value={`$${s.feesOutstanding}`} accent="red" />
        </div>
      ) : (
        <div className="card">Use the sidebar to navigate your available modules.</div>
      )}
    </div>
  );
}
