import { useEffect, useState } from 'react';
import api from '../api/client.js';
import DataTable from '../components/DataTable.jsx';
import { useAuth } from '../context/AuthContext.jsx';

export default function Exams() {
  const { user } = useAuth();
  const [exams, setExams] = useState([]);
  const load = () => api.get('/exams').then(r => setExams(r.data));
  useEffect(() => { load(); }, []);

  const publish = async (examId) => {
    const sectionId = prompt('Enter section ID to publish results for:');
    if (!sectionId) return;
    const { data } = await api.post(`/exams/${examId}/publish`, { sectionId: Number(sectionId) });
    alert(`Published ${data.published} report cards, notified ${data.notified} parents.`);
    load();
  };

  const columns = [
    { key:'name', label:'Exam' },
    { key:'status', label:'Status', render:r => (
      <span className={`badge ${r.status==='published'?'bg-emerald-100 text-emerald-700':r.status==='locked'?'bg-amber-100 text-amber-700':'bg-slate-100 text-slate-600'}`}>{r.status}</span>) },
    { key:'exam_date_start', label:'Start', render:r => (r.exam_date_start||'').slice(0,10) },
    { key:'actions', label:'Actions', render:r => user.role==='admin' && r.status!=='published'
      ? <button className="btn-primary text-xs py-1" onClick={()=>publish(r.id)}>Publish Results</button>
      : (r.status==='published' ? <span className="text-emerald-600 text-xs">✓ Published</span> : '-') },
  ];

  return (
    <div>
      <h2 className="text-2xl font-bold mb-5">Exams & Marks</h2>
      <div className="card mb-4 text-sm text-slate-600">
        Marks entry is available per exam-subject via the API (<code>POST /api/exams/marks</code>).
        Publishing an exam <b>locks all marks</b>, generates report-card PDFs, and emails parents automatically.
      </div>
      <DataTable columns={columns} rows={exams} empty="No exams created" />
    </div>
  );
}
