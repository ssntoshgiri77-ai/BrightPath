import { useEffect, useState } from 'react';
import api from '../api/client.js';
import DataTable from '../components/DataTable.jsx';

export default function AuditLog() {
  const [rows, setRows] = useState([]);
  useEffect(() => { api.get('/analytics/audit').then(r=>setRows(r.data)); }, []);
  const columns = [
    { key:'created_at', label:'Time', render:r=>new Date(r.created_at).toLocaleString() },
    { key:'actor_name', label:'Actor' },
    { key:'action', label:'Action' },
    { key:'entity', label:'Entity' },
    { key:'entity_id', label:'Entity ID' },
  ];
  return (
    <div>
      <h2 className="text-2xl font-bold mb-5">Audit Log</h2>
      <DataTable columns={columns} rows={rows} empty="No audit entries" />
    </div>
  );
}
