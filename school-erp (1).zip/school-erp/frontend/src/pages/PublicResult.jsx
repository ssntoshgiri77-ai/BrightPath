import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/client.js';

export default function PublicResult() {
  const [step, setStep] = useState(1);
  const [schoolCode, setSchoolCode] = useState('GWIS');
  const [lastName, setLastName] = useState('');
  const [dob, setDob] = useState('');
  const [requireOtp, setRequireOtp] = useState(true);
  const [exams, setExams] = useState([]);
  const [examId, setExamId] = useState('');
  const [lookup, setLookup] = useState(null);
  const [otp, setOtp] = useState('');
  const [result, setResult] = useState(null);
  const [err, setErr] = useState('');

  useEffect(() => { if (schoolCode) api.get('/public/exams', { params:{ schoolCode }}).then(r=>setExams(r.data)).catch(()=>{}); }, [schoolCode]);

  const doLookup = async (e) => {
    e.preventDefault(); setErr('');
    try {
      const { data } = await api.post('/public/lookup', { schoolCode, lastName, dateOfBirth:dob, requireOtp });
      setLookup(data); setStep(2);
      if (data.devCode) setOtp(data.devCode); // dev convenience
    } catch (e) { setErr(e.response?.data?.error || 'Lookup failed'); }
  };

  const doResult = async (e) => {
    e.preventDefault(); setErr('');
    try {
      const cand = lookup.candidates[0];
      const { data } = await api.post('/public/result', {
        schoolId: lookup.schoolId, studentId: cand.id, examId: Number(examId),
        otp: requireOtp ? otp : undefined,
      });
      setResult(data); setStep(3);
    } catch (e) { setErr(e.response?.data?.error || 'Could not fetch result'); }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-900 to-brand-700 p-4 flex items-center justify-center">
      <div className="card w-full max-w-lg">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-xl font-bold text-brand-900">🎓 Public Result Portal</h1>
          <Link to="/login" className="text-sm text-brand-600 hover:underline">Staff login →</Link>
        </div>
        {err && <div className="mb-4 rounded-lg bg-rose-50 text-rose-700 px-3 py-2 text-sm">{err}</div>}

        {step===1 && (
          <form onSubmit={doLookup} className="space-y-3">
            <p className="text-sm text-slate-500">Access your result with your last name and date of birth — no login required.</p>
            <div><label className="label">School Code</label><input className="input" value={schoolCode} onChange={e=>setSchoolCode(e.target.value)} required /></div>
            <div><label className="label">Last Name</label><input className="input" value={lastName} onChange={e=>setLastName(e.target.value)} required /></div>
            <div><label className="label">Date of Birth</label><input className="input" type="date" value={dob} onChange={e=>setDob(e.target.value)} required /></div>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={requireOtp} onChange={e=>setRequireOtp(e.target.checked)} /> Verify with OTP (recommended)</label>
            <button className="btn-primary w-full">Continue</button>
          </form>
        )}

        {step===2 && lookup && (
          <form onSubmit={doResult} className="space-y-3">
            <p className="text-sm">Student: <b>{lookup.candidates[0]?.name}</b> ({lookup.candidates[0]?.admissionNo})</p>
            <div><label className="label">Select Exam</label>
              <select className="input" value={examId} onChange={e=>setExamId(e.target.value)} required>
                <option value="">Select exam</option>{exams.map(x=><option key={x.id} value={x.id}>{x.name}</option>)}
              </select></div>
            {requireOtp && (
              <div><label className="label">OTP (sent to {lookup.maskedContact})</label>
                <input className="input" value={otp} onChange={e=>setOtp(e.target.value)} required /></div>
            )}
            <button className="btn-primary w-full" disabled={!examId}>View Result</button>
          </form>
        )}

        {step===3 && result && (
          <div>
            <h3 className="font-bold text-lg">{result.report.exam_name}</h3>
            <p className="text-slate-500 text-sm mb-3">{result.report.first_name} {result.report.last_name} · {result.report.class_name}-{result.report.section_name}</p>
            <table className="w-full text-sm mb-3">
              <thead className="bg-slate-100"><tr><th className="text-left px-3 py-2">Subject</th><th className="px-3 py-2">Max</th><th className="px-3 py-2">Obtained</th><th className="px-3 py-2">Grade</th></tr></thead>
              <tbody>{result.subjects.map((s,i)=>(<tr key={i} className="border-t"><td className="px-3 py-2">{s.name}</td><td className="text-center">{s.max_marks}</td><td className="text-center">{s.marks_obtained}</td><td className="text-center">{s.grade}</td></tr>))}</tbody>
            </table>
            <div className="grid grid-cols-3 gap-2 text-center mb-3">
              <div className="bg-slate-50 rounded-lg p-2"><p className="text-xs text-slate-500">Total</p><p className="font-bold">{result.report.total_marks}/{result.report.max_total}</p></div>
              <div className="bg-slate-50 rounded-lg p-2"><p className="text-xs text-slate-500">Percentage</p><p className="font-bold">{result.report.percentage}%</p></div>
              <div className="bg-slate-50 rounded-lg p-2"><p className="text-xs text-slate-500">Grade</p><p className="font-bold">{result.report.overall_grade}</p></div>
            </div>
            {result.pdfUrl && <a className="btn-primary w-full" href={result.pdfUrl} target="_blank" rel="noreferrer">Download Report Card PDF</a>}
          </div>
        )}
      </div>
    </div>
  );
}
